
'use client';

import { useState, useEffect } from 'react';

type Attribute = { id: string; name: string; productCount?: number; };

export const useAttributeData = (title: string, fallbackData: Attribute[]) => {
  const [data, setData] = useState<Attribute[]>(fallbackData);
  const storageKey = `attributes_${title.toLowerCase().replace(/[^a-z0-9]/g, '_')}`;

  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        const storedData = window.localStorage.getItem(storageKey);
        if (storedData) {
          setData(JSON.parse(storedData));
        } else {
          // If not in storage, use fallback and save it
          setData(fallbackData);
          window.localStorage.setItem(storageKey, JSON.stringify(fallbackData));
        }
      } catch (error) {
        console.error(`Failed to load ${title} from localStorage`, error);
        setData(fallbackData);
      }
    }
  }, [storageKey, title, fallbackData]);

  return data;
};
