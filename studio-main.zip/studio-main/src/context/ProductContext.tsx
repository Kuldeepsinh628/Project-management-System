
'use client';

import * as React from 'react';
import type { Product } from '@/lib/definitions';
import { PRODUCTS as initialProducts } from '@/lib/placeholder-data';

type ProductContextType = {
  products: Product[];
  addProduct: (product: Omit<Product, 'id'>) => void;
  addProductsBatch: (products: Omit<Product, 'id' | 'lastUpdated' | 'imageId'>[]) => void;
  updateProduct: (product: Product) => void;
  deleteProduct: (productId: string) => void;
};

const ProductContext = React.createContext<ProductContextType | undefined>(undefined);

// Helper to sort products alphabetically
const sortProducts = (products: Product[]): Product[] => {
  return products.sort((a, b) => a.fixtureName.localeCompare(b.fixtureName));
};


// Helper function to load products from localStorage
const loadProductsFromStorage = (): Product[] => {
  if (typeof window === 'undefined') {
    return sortProducts(initialProducts);
  }
  try {
    const storedProducts = window.localStorage.getItem('products');
    return storedProducts ? sortProducts(JSON.parse(storedProducts)) : sortProducts(initialProducts);
  } catch (error) {
    console.error("Failed to parse products from localStorage", error);
    return sortProducts(initialProducts);
  }
};

// Helper function to save products to localStorage
const saveProductsToStorage = (products: Product[]) => {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem('products', JSON.stringify(products));
  } catch (error) {
    console.error("Failed to save products to localStorage", error);
  }
};


export function ProductProvider({ children }: { children: React.ReactNode }) {
  const [products, setProducts] = React.useState<Product[]>(() => loadProductsFromStorage());

  // Effect to save products whenever they change
  React.useEffect(() => {
    saveProductsToStorage(products);
  }, [products]);

  const addProduct = (newProductData: Omit<Product, 'id'>) => {
    const newProduct: Product = {
      ...newProductData,
      id: `prod-${Date.now()}`,
    };
    setProducts(prevProducts => sortProducts([newProduct, ...prevProducts]));
  };

  const addProductsBatch = (batch: Omit<Product, 'id' | 'lastUpdated' | 'imageId'>[]) => {
    const newProducts = batch.map((p, i) => ({
        ...p,
        id: `prod-${Date.now()}-${i}`,
        lastUpdated: new Date().toISOString(),
        imageId: `img-${Date.now()}-${i}`,
    }));
    setProducts(prevProducts => sortProducts([...newProducts, ...prevProducts]));
  };

  const updateProduct = (updatedProduct: Product) => {
    setProducts(prevProducts =>
      sortProducts(prevProducts.map(p => (p.id === updatedProduct.id ? updatedProduct : p)))
    );
  };

  const deleteProduct = (productId: string) => {
    setProducts(prevProducts => sortProducts(prevProducts.filter(p => p.id !== productId)));
  };

  const value = {
    products,
    addProduct,
    addProductsBatch,
    updateProduct,
    deleteProduct,
  };

  return <ProductContext.Provider value={value}>{children}</ProductContext.Provider>;
}

export function useProducts() {
  const context = React.useContext(ProductContext);
  if (context === undefined) {
    throw new Error('useProducts must be used within a ProductProvider');
  }
  return context;
}
