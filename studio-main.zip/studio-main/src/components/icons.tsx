import type { SVGProps } from 'react';

export function Logo(props: SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 20" {...props}>
      <text
        x="0"
        y="15"
        fontFamily="'Space Grotesk', sans-serif"
        fontSize="16"
        fontWeight="bold"
        fill="currentColor"
      >
        Plus Light Tech
      </text>
    </svg>
  );
}
