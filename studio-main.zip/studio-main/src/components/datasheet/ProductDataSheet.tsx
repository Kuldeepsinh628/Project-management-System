
'use client';

import type { Product } from '@/lib/definitions';
import { getDirectImageUrl, loadImageAsBase64 } from '@/lib/utils';
import * as React from 'react';

// Extended type to allow for additional image fields
type ProductWithImage = Product & { 
  productImage?: string; 
  dimensionDrawing?: string; 
  photometricChart?: string;
  certificateAvailable?: string;
  binning?: string;
};

interface ProductDataSheetProps {
  product: Partial<ProductWithImage>;
  imageUrls?: {
    main: string | null;
    dimension: string | null;
    photometric: string | null;
  }
}


const DataSheetRow = ({ label, value }: { label: string; value?: string | number | null }) => {
    if (value === null || value === undefined || value === '') return null;
    return (
        <div className="flex justify-between py-1 text-xs border-b border-gray-200">
            <span className="font-medium text-gray-600 w-2/5 pr-2">{label}</span>
            <span className="text-gray-800 text-left w-3/5">{String(value)}</span>
        </div>
    );
};

const SectionTitle = ({ title }: { title: string }) => (
    <h2 className="text-base font-semibold text-gray-800 border-b-2 border-gray-300 pb-1 mb-3 mt-4">{title}</h2>
);


export const ProductDataSheet = ({ product, imageUrls }: ProductDataSheetProps) => {
    const getTunableDimmable = () => {
        if (product.tunable && product.dimmable) return 'Tunable & Dimmable';
        if (product.tunable) return 'Tunable';
        if (product.dimmable) return 'Dimmable';
        return 'Non-Dimmable / Contact for options';
    }

  return (
    <div id="datasheet-container" className="w-[210mm] h-[297mm] bg-white p-8 font-sans text-sm text-gray-800 flex flex-col">
        
        {/* Header */}
        <header className="mb-6 border-b-4 border-gray-400 pb-4">
            <h1 className="text-4xl font-bold text-gray-900 font-headline">{product.fixtureName || 'Product Datasheet'}</h1>
            <p className="text-lg text-gray-600">{product.variant || 'Product Variant'}</p>
        </header>

        <main className="flex-grow grid grid-cols-2 gap-8">
            {/* Left Column: Details */}
            <div className="col-span-1 flex flex-col">
                
                {product.description && (
                    <div className="mb-4">
                        <p className="text-sm text-gray-700 italic">{product.description}</p>
                    </div>
                )}
                
                <div>
                    <SectionTitle title="Technical Details" />
                    <DataSheetRow label="Model Name" value={product.fixtureName} />
                    <DataSheetRow label="Variant" value={product.variant} />
                    <DataSheetRow label="Category" value={product.category} />
                    <DataSheetRow label="Subcategory" value={product.subcategory} />
                    <DataSheetRow label="Mounting Type" value={product.mountingType} />
                    <DataSheetRow label="IP Rating" value={product.ipRating} />
                    <DataSheetRow label="IK Rating" value={product.ikRating} />
                    <DataSheetRow label="Weight" value={product.weight ? `${product.weight} kg` : null} />
                    <DataSheetRow label="Colors Available" value={product.colors} />
                    <DataSheetRow label="Lifetime" value={product.lifetime} />
                    <DataSheetRow label="Certificate Available" value={product.gunioReport} />
                </div>

                <div>
                     <SectionTitle title="Photometric" />
                     <DataSheetRow label="System Lumen (lm)" value={product.lumen ? `${product.lumen} lm` : null} />
                     <DataSheetRow label="System Wattage (W)" value={product.wattage ? `${product.wattage} W` : null} />
                     <DataSheetRow label="Efficacy (lm/W)" value={product.efficacy ? `${product.efficacy} lm/W` : null} />
                     <DataSheetRow label="CCT (K)" value={product.cct} />
                     <DataSheetRow label="CRI" value={product.cri} />
                     <DataSheetRow label="Beam Angle (°)" value={product.beamAngle ? `${product.beamAngle}°` : null} />
                     <DataSheetRow label="Binning" value={product.binning} />
                     <DataSheetRow label="UGR" value={product.ugr} />
                     <DataSheetRow label="Actual BUG" value={product.bcr} />
                </div>
                
                <div>
                     <SectionTitle title="Electrical" />
                     <DataSheetRow label="DC Current (mA)" value={product.drivingCurrent ? `${product.drivingCurrent} mA` : null}/>
                     <DataSheetRow label="Driver Type" value={product.driverType} />
                     <DataSheetRow label="THD" value={product.thd} />
                     <DataSheetRow label="Control" value={getTunableDimmable()} />
                     <DataSheetRow label="Input" value={product.integratedRemote} />
                </div>

                 <div>
                     <SectionTitle title="Pricing" />
                     <DataSheetRow label="Price (INR)" value={product.priceINR ? `₹${product.priceINR.toLocaleString('en-IN')}` : null} />
                     <DataSheetRow label="Price (USD)" value={product.priceUSD ? `$${product.priceUSD.toLocaleString('en-US')}` : null} />
                     <DataSheetRow label="Price (AED)" value={product.priceAED ? `د.إ${product.priceAED.toLocaleString('ar-AE')}` : null} />
                     <DataSheetRow label="Price (AUD)" value={product.priceAUD ? `A$${product.priceAUD.toLocaleString('en-AU')}` : null} />
                     <DataSheetRow label="Price (GBP)" value={product.priceGBP ? `£${product.priceGBP.toLocaleString('en-GB')}` : null} />
                </div>
            </div>

            {/* Right Column: Images */}
            <div className="col-span-1 space-y-4">
                 {(imageUrls?.main || product.imageUrl) && (
                    <div className="flex items-center justify-center border rounded-lg p-2 aspect-square h-[240px] overflow-hidden">
                       <img src={imageUrls?.main || getDirectImageUrl(product.imageUrl)} alt="Product Main" className="max-w-full max-h-full object-contain"/>
                    </div>
                )}
                {(imageUrls?.dimension || product.dimensionUrl) && (
                    <div className="flex items-center justify-center border rounded-lg p-2 aspect-square h-[240px] overflow-hidden">
                        <img src={imageUrls?.dimension || getDirectImageUrl(product.dimensionUrl)} alt="Dimension Drawing" className="max-w-full max-h-full object-contain"/>
                    </div>
                )}
                {(imageUrls?.photometric || product.photometricChartUrl) && (
                    <div className="flex items-center justify-center border rounded-lg p-2 aspect-square h-[240px] overflow-hidden">
                        <img src={imageUrls?.photometric || getDirectImageUrl(product.photometricChartUrl)} alt="Photometric Chart" className="max-w-full max-h-full object-contain"/>
                    </div>
                )}
            </div>
        </main>
        
        <footer className="flex justify-between items-center mt-auto pt-4 border-t-2 border-gray-300">
            <p className="text-xs text-gray-500">Plus Light Tech - High Performance Lighting</p>
            <p className="text-xs text-gray-500">Generated on: {new Date().toLocaleDateString()}</p>
        </footer>
    </div>
  );
};
