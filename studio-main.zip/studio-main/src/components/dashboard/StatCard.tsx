
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import type { StatCard as StatCardType } from '@/lib/definitions';
import { cn } from '@/lib/utils';

export default function StatCard({ label, value, icon: Icon, href }: StatCardType) {
  const isClickable = !!href;
  
  return (
    <Card className={cn(
      isClickable && "hover:bg-muted/50 transition-colors"
    )}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{label}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
      </CardContent>
    </Card>
  );
}
