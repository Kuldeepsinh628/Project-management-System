'use client';
import { Bar, BarChart, CartesianGrid, XAxis, YAxis } from 'recharts';

import {
  ChartConfig,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from '@/components/ui/chart';
import { CATEGORIES } from '@/lib/placeholder-data';

const chartData = CATEGORIES.map(category => ({
  name: category.name,
  products: category.productCount,
}));

const chartConfig = {
  products: {
    label: 'Products',
    color: 'hsl(var(--primary))',
  },
} satisfies ChartConfig;

export default function ProductsChart() {
  return (
    <ChartContainer config={chartConfig} className="min-h-[200px] w-full">
      <BarChart accessibilityLayer data={chartData}>
        <CartesianGrid vertical={false} />
        <XAxis
          dataKey="name"
          tickLine={false}
          tickMargin={10}
          axisLine={false}
          tickFormatter={(value) => value.slice(0, 3)}
        />
        <YAxis />
        <ChartTooltip
          cursor={false}
          content={<ChartTooltipContent indicator="dot" />}
        />
        <Bar dataKey="products" fill="var(--color-products)" radius={4} />
      </BarChart>
    </ChartContainer>
  );
}
