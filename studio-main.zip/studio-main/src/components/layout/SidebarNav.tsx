
'use client';
import {
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarSeparator,
} from '@/components/ui/sidebar';
import {
  Cog,
  FileText,
  Home,
  Package,
  FileUp,
  Users,
  Lightbulb,
  LogOut,
} from 'lucide-react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { Logo } from '@/components/icons';
import { useUser } from '@/firebase';
import type { User as AppUser } from '@/lib/definitions';
import { useState, useEffect } from 'react';

export default function SidebarNav() {
  const pathname = usePathname();
  const router = useRouter();
  const { user: appUser, setUser: setAppUser } = useUser();

  const isAdmin = appUser?.role === 'Admin';
  const canEdit = isAdmin || appUser?.role === 'Editor';
  const isViewer = appUser?.role === 'Viewer';

  const links = [
    { href: '/dashboard', label: 'Dashboard', icon: Home, visible: true },
    { href: '/products', label: 'Products', icon: Package, visible: true },
    { href: '/import', label: 'Bulk Import', icon: FileUp, visible: canEdit },
    { href: '/generate', label: 'Datasheet Generator', icon: FileText, visible: true },
    { href: '/users', label: 'Users', icon: Users, visible: isAdmin },
    { href: '/settings', label: 'Settings', icon: Cog, visible: canEdit && !isViewer },
  ];
  
  const handleLogout = async () => {
    sessionStorage.removeItem('loggedInUser');
    if(setAppUser) {
      setAppUser(null);
    }
    router.push('/login');
  };

  return (
    <>
      <SidebarHeader>
        <div className="flex items-center gap-2">
          <Lightbulb className="h-8 w-8 text-sidebar-primary" />
          <Logo className="h-6 w-28 text-sidebar-foreground group-data-[collapsible=icon]:hidden" />
        </div>
      </SidebarHeader>
      <SidebarContent className="p-2">
        <SidebarMenu>
          {links.map((link) => {
            if (!link.visible) {
              return null;
            }
            const isActive = pathname.startsWith(link.href);
            return (
              <SidebarMenuItem key={link.href}>
                <Link href={link.href}>
                  <SidebarMenuButton
                    isActive={isActive}
                    tooltip={{ children: link.label }}
                  >
                    <link.icon className="h-5 w-5" />
                    <span>{link.label}</span>
                  </SidebarMenuButton>
                </Link>
              </SidebarMenuItem>
            );
          })}
        </SidebarMenu>
      </SidebarContent>
      <SidebarFooter className="p-2">
        <SidebarSeparator />
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton onClick={handleLogout} tooltip={{ children: 'Logout' }}>
              <LogOut className="h-5 w-5" />
              <span>Logout</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </>
  );
}
