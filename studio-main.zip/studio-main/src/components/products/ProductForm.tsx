
'use client';

import { useForm, type UseFormReturn } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Upload, X, Loader2, ExternalLink, BarChart3, Ruler } from 'lucide-react';
import type { Product, Category, SubCategory, Variant, MountingType } from '@/lib/definitions';
import { CATEGORIES as placeholderCategories, SUBCATEGORIES as placeholderSubCategories, VARIANTS as placeholderVariants, MOUNTING_TYPES as placeholderMountingTypes } from '@/lib/placeholder-data';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import Image from 'next/image';
import { useState, useRef, useEffect, useMemo } from 'react';
import { Switch } from '../ui/switch';
import { uploadImage } from '@/firebase/storage';
import { useProducts } from '@/context/ProductContext';
import { getDirectImageUrl, isGoogleDriveFolder } from '@/lib/utils';

const productFormSchema = z.object({
  fixtureName: z.string().min(2, {
    message: 'Product name must be at least 2 characters.',
  }),
  description: z.string().max(500).optional(),
  category: z.string().optional(),
  subcategory: z.string().optional(),
  variant: z.string().optional(),
  mountingType: z.string().optional(),
  
  nmw: z.string().optional(),
  colors: z.string().optional(),
  cct: z.string().optional(),
  cri: z.string().optional(),
  wattage: z.string().optional(),
  lumen: z.string().optional(),
  beamAngle: z.string().optional(),
  ipRating: z.string().optional(),
  ikRating: z.string().optional(),

  efficacy: z.string().optional(),
  lifetime: z.string().optional(),
  driverType: z.string().optional(),
  
  drivingCurrent: z.string().optional(),
  efficiency: z.string().optional(),
  ugr: z.string().optional(),
  bcr: z.string().optional(),
binning: z.string().optional(),
  thd: z.string().optional(),
  tunable: z.boolean().default(false),
  dimmable: z.boolean().default(false),
  integratedRemote: z.string().optional(),
  weight: z.string().optional(),
  status: z.string().optional(),
  gunioReport: z.string().optional(),
  remarks: z.string().optional(),
  testedDate: z.string().optional(),

  imageUrl: z.string().url().optional().or(z.literal('')),
  datasheetUrl: z.string().url().optional().or(z.literal('')),
  iesFileUrl: z.string().url().optional().or(z.literal('')),
  revitFileUrl: z.string().url().optional().or(z.literal('')),
  dimensionUrl: z.string().url().optional().or(z.literal('')),
  photometricChartUrl: z.string().url().optional().or(z.literal('')),
  installationGuide: z.string().url().optional().or(z.literal('')),
  priceINR: z.number().optional().nullable(),
  priceUSD: z.number().optional().nullable(),
  priceAED: z.number().optional().nullable(),
  priceAUD: z.number().optional().nullable(),
  priceGBP: z.number().optional().nullable(),
  createdAt: z.string().optional(),
  datasheetHtml: z.string().optional(),
});

type ProductFormValues = z.infer<typeof productFormSchema>;

type Attribute = { id: string; name: string; productCount?: number; };

const useAttributeData = (title: string, fallbackData: Attribute[]) => {
  const [data, setData] = useState<Attribute[]>(fallbackData);
  const storageKey = `attributes_${title.toLowerCase().replace(/[^a-z0-9]/g, '_')}`;

  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        const storedData = window.localStorage.getItem(storageKey);
        if (storedData) {
          setData(JSON.parse(storedData));
        } else {
          setData(fallbackData);
        }
      } catch (error) {
        console.error(`Failed to load ${title} from localStorage`, error);
        setData(fallbackData);
      }
    }
  }, [storageKey, title, fallbackData]);
  
  return data;
};

const FileUploadField = ({ field, label, isSubmitting, onFileChange, onClear, fileRef, icon: Icon }: any) => {
  const fileUrl = field.value;
  const isUrlFolder = isGoogleDriveFolder(fileUrl);
  const [isUploading, setIsUploading] = useState(false);

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setIsUploading(true);
      try {
        await onFileChange(file, field.name);
      } finally {
        setIsUploading(false);
      }
    }
  };

  const renderIcon = () => {
    if (Icon && label === "Product Image") {
      return <Image src={getDirectImageUrl(fileUrl)} alt="Product Preview" width={24} height={24} className="rounded-sm" />;
    }
    if (Icon) {
      return <Icon className="h-4 w-4" />;
    }
    return null;
  };

  return (
    <FormItem>
      <FormLabel>{label}</FormLabel>
      {isUrlFolder ? (
        <a href={fileUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 p-2 rounded-md border bg-secondary">
          <ExternalLink className="h-4 w-4" />
          <span className="text-sm truncate">View Folder</span>
        </a>
      ) : fileUrl ? (
        <div className="flex items-center gap-2 p-2 rounded-md border">
          {renderIcon()}
          <span className="text-sm truncate flex-1">{fileUrl.split('/').pop()?.split('?')[0]}</span>
          <Button type="button" variant="ghost" size="icon" className="h-6 w-6" onClick={() => onClear(field.name)} disabled={isUploading || isSubmitting}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      ) : (
        <FormLabel className="flex items-center gap-2 p-2 rounded-md border border-dashed cursor-pointer">
          {isUploading ? (
             <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
             <Upload className="h-4 w-4 text-muted-foreground" />
          )}
          <span className="text-sm text-muted-foreground">
            {isUploading ? 'Uploading...' : 'Choose File'}
          </span>
          <FormControl>
            <Input
              type="file"
              className="sr-only"
              ref={fileRef}
              onChange={handleFileChange}
              disabled={isUploading || isSubmitting}
            />
          </FormControl>
        </FormLabel>
      )}
       <FormField
          control={field.control}
          name={field.name}
          render={({ field: urlField }) => (
            <FormItem>
              <FormControl><Input type="url" placeholder="Or paste URL" {...urlField} disabled={isSubmitting} value={urlField.value ?? ''} /></FormControl>
              <FormMessage />
            </FormItem>
        )}/>
    </FormItem>
  );
};

type ProductFormProps = {
  product?: Product;
  formMethods?: UseFormReturn<any>; // Allow passing form methods from parent
  onSubmit?: (data: ProductFormValues) => void;
  showSubmitButton?: boolean;
};


export default function ProductForm({ product: initialProduct, formMethods, onSubmit: parentOnSubmit, showSubmitButton = true }: ProductFormProps) {
  const router = useRouter();
  const { toast } = useToast();
  const { addProduct, updateProduct, products } = useProducts();
  
  const productImageFileRef = useRef<HTMLInputElement>(null);
  const dimensionUrlFileRef = useRef<HTMLInputElement>(null);
  const photometricChartUrlFileRef = useRef<HTMLInputElement>(null);

  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const internalForm = useForm<ProductFormValues>({
    resolver: zodResolver(productFormSchema),
    defaultValues: initialProduct ? {
      ...initialProduct,
      wattage: initialProduct.wattage?.toString(),
      beamAngle: initialProduct.beamAngle?.toString(),
    } : {},
  });

  const form = formMethods || internalForm;

  const categories = useAttributeData('Categories', placeholderCategories);
  const subCategories = useAttributeData('Sub-Categories', placeholderSubCategories);
  const variantsData = useAttributeData('Variants', placeholderVariants);
  const mountingTypes = useAttributeData('Mounting Types', placeholderMountingTypes);

  useEffect(() => {
    if (initialProduct) {
      form.reset({
        ...initialProduct,
        wattage: initialProduct.wattage?.toString() ?? '',
        beamAngle: initialProduct.beamAngle?.toString() ?? '',
      });
    }
  }, [initialProduct, form]);


  const handleFileUpload = async (file: File, fieldName: keyof ProductFormValues) => {
      try {
        const uploadPath = `product-files/${Date.now()}_${file.name}`;
        const downloadURL = await uploadImage(file, uploadPath);
        form.setValue(fieldName, downloadURL, { shouldValidate: true });
        toast({
          title: 'File Uploaded',
          description: 'The file has been successfully uploaded.',
        });
      } catch (error) {
        console.error('File upload failed:', error);
        toast({
          variant: 'destructive',
          title: 'Upload Failed',
          description: 'Could not upload the file. Please try again.',
        });
        form.setValue(fieldName, '', { shouldValidate: true });
      }
  };

  const clearFile = (fieldName: keyof ProductFormValues) => {
    form.setValue(fieldName, '');
    switch(fieldName) {
      case 'imageUrl':
        if (productImageFileRef.current) productImageFileRef.current.value = '';
        break;
      case 'dimensionUrl':
        if (dimensionUrlFileRef.current) dimensionUrlFileRef.current.value = '';
        break;
      case 'photometricChartUrl':
        if (photometricChartUrlFileRef.current) photometricChartUrlFileRef.current.value = '';
        break;
    }
  }

  async function onSubmit(data: ProductFormValues) {
     if (parentOnSubmit) {
      parentOnSubmit(data);
      return;
    }

    setIsSubmitting(true);
    
    try {
      if (initialProduct) {
        // When updating, merge the form data with the existing product data
        // to ensure no fields are lost.
        const updatedProductData = {
          ...initialProduct,
          ...data,
          lastUpdated: new Date().toISOString(),
        };
        updateProduct(updatedProductData);
      } else {
        const newProductData = {
          ...data,
          variants: 1,
          lastUpdated: new Date().toISOString(),
          imageId: `img-${Date.now()}`,
        };
        addProduct(newProductData as Omit<Product, 'id'>);
      }

      toast({
        title: `Product ${initialProduct ? 'Updated' : 'Created'}`,
        description: `The product "${data.fixtureName}" has been successfully ${initialProduct ? 'updated' : 'saved'}.`,
      });
      router.push('/products');

    } catch (error) {
      console.error('Submission failed:', error);
      toast({
        variant: 'destructive',
        title: 'Submission Failed',
        description: 'Could not save the product. Please try again.',
      });
    } finally {
      setIsSubmitting(false);
    }
  }
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-8">
            <Card>
              <CardHeader>
                <CardTitle>Basic Information</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="fixtureName"
                  render={({ field }) => (
                    <FormItem className="md:col-span-2">
                      <FormLabel>Product Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., Aura Recessed Downlight" {...field} value={field.value ?? ''} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="nmw"
                  render={({ field }) => (
                    <FormItem><FormLabel>NMW</FormLabel><FormControl><Input placeholder="e.g., AUR-R-3K-WHT" {...field} value={field.value ?? ''} /></FormControl><FormMessage /></FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="colors"
                  render={({ field }) => (
                    <FormItem><FormLabel>Colors</FormLabel><FormControl><Input placeholder="e.g., Matte White" {...field} value={field.value ?? ''} /></FormControl><FormMessage /></FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem className="md:col-span-2">
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="A brief description of the product."
                          className="resize-none"
                          {...field}
                          value={field.value ?? ''}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="remarks"
                  render={({ field }) => (
                    <FormItem className="md:col-span-2">
                      <FormLabel>Remarks</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Internal remarks or notes."
                          className="resize-none"
                          {...field}
                          value={field.value ?? ''}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Taxonomy</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField control={form.control} name="category" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value ?? ''}>
                      <FormControl><SelectTrigger><SelectValue placeholder="Select a category" /></SelectTrigger></FormControl>
                      <SelectContent>{categories.map(c=><SelectItem key={c.id} value={c.name}>{c.name}</SelectItem>)}</SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}/>
                <FormField control={form.control} name="subcategory" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Subcategory</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value ?? ''}>
                      <FormControl><SelectTrigger><SelectValue placeholder="Select a subcategory" /></SelectTrigger></FormControl>
                      <SelectContent>{subCategories.map(c=><SelectItem key={c.id} value={c.name}>{c.name}</SelectItem>)}</SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}/>
                <FormField control={form.control} name="variant" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Variant</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value ?? ''}>
                      <FormControl><SelectTrigger><SelectValue placeholder="Select a variant" /></SelectTrigger></FormControl>
                      <SelectContent>{variantsData.map(s=><SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>)}</SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}/>
                <FormField control={form.control} name="mountingType" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Mounting Type</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value ?? ''}>
                      <FormControl><SelectTrigger><SelectValue placeholder="Select a mounting type" /></SelectTrigger></FormControl>
                      <SelectContent>{mountingTypes.map(m=><SelectItem key={m.id} value={m.name}>{m.name}</SelectItem>)}</SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}/>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Technical Specifications</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <FormField control={form.control} name="cct" render={({ field }) => (
                  <FormItem><FormLabel>CCT (K)</FormLabel><FormControl><Input placeholder="e.g., 3000K" {...field} value={field.value ?? ''} /></FormControl><FormMessage /></FormItem>
                )}/>
                 <FormField control={form.control} name="cri" render={({ field }) => (
                  <FormItem><FormLabel>CRI</FormLabel><FormControl><Input placeholder="e.g., 90+" {...field} value={field.value ?? ''} /></FormControl><FormMessage /></FormItem>
                )}/>
                <FormField control={form.control} name="wattage" render={({ field }) => (
                  <FormItem><FormLabel>Wattage (W)</FormLabel><FormControl><Input type="text" placeholder="12" {...field} value={field.value ?? ''} /></FormControl><FormMessage /></FormItem>
                )}/>
                <FormField control={form.control} name="lumen" render={({ field }) => (
                  <FormItem><FormLabel>Lumen Output (lm)</FormLabel><FormControl><Input placeholder="1100" {...field} value={field.value ?? ''} /></FormControl><FormMessage /></FormItem>
                )}/>
                <FormField control={form.control} name="beamAngle" render={({ field }) => (
                  <FormItem><FormLabel>Beam Angle (°)</FormLabel><FormControl><Input type="text" placeholder="38" {...field} value={field.value ?? ''} /></FormControl><FormMessage /></FormItem>
                )}/>
                <FormField control={form.control} name="ipRating" render={({ field }) => (
                  <FormItem><FormLabel>IP Rating</FormLabel><FormControl><Input placeholder="e.g., IP44" {...field} value={field.value ?? ''} /></FormControl><FormMessage /></FormItem>
                )}/>
                 <FormField control={form.control} name="ikRating" render={({ field }) => (
                  <FormItem><FormLabel>IK Rating</FormLabel><FormControl><Input placeholder="e.g., IK08" {...field} value={field.value ?? ''} /></FormControl><FormMessage /></FormItem>
                )}/>
                 <FormField control={form.control} name="efficacy" render={({ field }) => (
                  <FormItem><FormLabel>Efficacy (lm/W)</FormLabel><FormControl><Input placeholder="e.g., 92" {...field} value={field.value ?? ''} /></FormControl></FormItem>
                )}/>
                <FormField control={form.control} name="efficiency" render={({ field }) => (
                    <FormItem><FormLabel>Efficiency</FormLabel><FormControl><Input placeholder="e.g., 85%" {...field} value={field.value ?? ''} /></FormControl></FormItem>
                )}/>
                <FormField control={form.control} name="drivingCurrent" render={({ field }) => (
                    <FormItem><FormLabel>DC Current (mA)</FormLabel><FormControl><Input placeholder="e.g., 350" {...field} value={field.value ?? ''} /></FormControl></FormItem>
                )}/>
                <FormField control={form.control} name="ugr" render={({ field }) => (
                    <FormItem><FormLabel>UGR</FormLabel><FormControl><Input placeholder="e.g., <19" {...field} value={field.value ?? ''} /></FormControl></FormItem>
                )}/>
                <FormField control={form.control} name="bcr" render={({ field }) => (
                    <FormItem><FormLabel>Actual BUG</FormLabel><FormControl><Input placeholder="e.g., B3" {...field} value={field.value ?? ''} /></FormControl></FormItem>
                )}/>
                <FormField control={form.control} name="binning" render={({ field }) => (
                    <FormItem><FormLabel>Binning</FormLabel><FormControl><Input placeholder="e.g., 3-step MacAdam" {...field} value={field.value ?? ''} /></FormControl></FormItem>
                )}/>
                <FormField control={form.control} name="thd" render={({ field }) => (
                    <FormItem><FormLabel>THD</FormLabel><FormControl><Input placeholder="e.g., <15%" {...field} value={field.value ?? ''} /></FormControl></FormItem>
                )}/>
                 <FormField control={form.control} name="weight" render={({ field }) => (
                  <FormItem><FormLabel>Weight (kg)</FormLabel><FormControl><Input placeholder="0.5" {...field} value={field.value ?? ''} /></FormControl><FormMessage /></FormItem>
                )}/>
              </CardContent>
            </Card>

             <Card>
              <CardHeader>
                <CardTitle>Pricing</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <FormField control={form.control} name="priceINR" render={({ field }) => (
                  <FormItem><FormLabel>INR (₹)</FormLabel><FormControl><Input type="number" placeholder="e.g., 5000" {...field} value={field.value ?? ''} onChange={e => field.onChange(e.target.value === '' ? null : e.target.valueAsNumber)} /></FormControl><FormMessage /></FormItem>
                )}/>
                <FormField control={form.control} name="priceUSD" render={({ field }) => (
                  <FormItem><FormLabel>USD ($)</FormLabel><FormControl><Input type="number" placeholder="e.g., 60" {...field} value={field.value ?? ''} onChange={e => field.onChange(e.target.value === '' ? null : e.target.valueAsNumber)} /></FormControl><FormMessage /></FormItem>
                )}/>
                <FormField control={form.control} name="priceAED" render={({ field }) => (
                  <FormItem><FormLabel>AED (د.إ)</FormLabel><FormControl><Input type="number" placeholder="e.g., 220" {...field} value={field.value ?? ''} onChange={e => field.onChange(e.target.value === '' ? null : e.target.valueAsNumber)} /></FormControl><FormMessage /></FormItem>
                )}/>
                <FormField control={form.control} name="priceAUD" render={({ field }) => (
                  <FormItem><FormLabel>AUD (A$)</FormLabel><FormControl><Input type="number" placeholder="e.g., 90" {...field} value={field.value ?? ''} onChange={e => field.onChange(e.target.value === '' ? null : e.target.valueAsNumber)} /></FormControl><FormMessage /></FormItem>
                )}/>
                <FormField control={form.control} name="priceGBP" render={({ field }) => (
                  <FormItem><FormLabel>GBP (£)</FormLabel><FormControl><Input type="number" placeholder="e.g., 48" {...field} value={field.value ?? ''} onChange={e => field.onChange(e.target.value === '' ? null : e.target.valueAsNumber)} /></FormControl><FormMessage /></FormItem>
                )}/>
              </CardContent>
            </Card>

             <Card>
              <CardHeader>
                <CardTitle>Additional Details</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-2 md:grid-cols-3 gap-6">
                 <FormField control={form.control} name="lifetime" render={({ field }) => (
                  <FormItem><FormLabel>Lifetime</FormLabel><FormControl><Input placeholder="e.g., L80/B10 >50,000h" {...field} value={field.value ?? ''} /></FormControl><FormMessage /></FormItem>
                )}/>
                 <FormField control={form.control} name="driverType" render={({ field }) => (
                  <FormItem><FormLabel>Driver Type</FormLabel><FormControl><Input placeholder="e.g., Constant Current" {...field} value={field.value ?? ''} /></FormControl><FormMessage /></FormItem>
                )}/>
                 <FormField control={form.control} name="status" render={({ field }) => (
                    <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value ?? ''}>
                        <FormControl><SelectTrigger><SelectValue placeholder="Select a status" /></SelectTrigger></FormControl>
                        <SelectContent>
                        <SelectItem value="Uploaded">Uploaded</SelectItem>
                        <SelectItem value="Ready to Upload">Ready to Upload</SelectItem>
                        <SelectItem value="Not Uploaded">Not Uploaded</SelectItem>
                        </SelectContent>
                    </Select>
                    <FormMessage />
                    </FormItem>
                 )}/>
                 <FormField control={form.control} name="testedDate" render={({ field }) => (
                  <FormItem><FormLabel>Tested Date</FormLabel><FormControl><Input type="date" {...field} value={field.value ? new Date(field.value).toISOString().split('T')[0] : ''} /></FormControl><FormMessage /></FormItem>
                 )}/>
                 <FormField control={form.control} name="gunioReport" render={({ field }) => (
                    <FormItem><FormLabel>Certificate Available</FormLabel><FormControl><Input placeholder="e.g., Yes" {...field} value={field.value ?? ''} /></FormControl></FormItem>
                 )}/>
                 <FormField control={form.control} name="integratedRemote" render={({ field }) => (
                    <FormItem><FormLabel>Input</FormLabel><FormControl><Input placeholder="e.g., DALI" {...field} value={field.value ?? ''} /></FormControl></FormItem>
                 )}/>

                 <div className="flex flex-col gap-4">
                  <FormField
                    control={form.control}
                    name="tunable"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                        <div className="space-y-0.5">
                          <FormLabel>Tunable</FormLabel>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                   <FormField
                    control={form.control}
                    name="dimmable"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                        <div className="space-y-0.5">
                          <FormLabel>Dimmable</FormLabel>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
              </CardContent>
            </Card>

          </div>

          <div className="space-y-8">
             <Card>
              <CardHeader><CardTitle>Media &amp; Files</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <FormField
                  control={form.control}
                  name="imageUrl"
                  render={({ field }) => (
                     <FileUploadField
                      field={field}
                      label="Product Image"
                      isSubmitting={isSubmitting}
                      onFileChange={handleFileUpload}
                      onClear={clearFile}
                      fileRef={productImageFileRef}
                      icon={Image}
                    />
                  )}
                />
                 <FormField
                  control={form.control}
                  name="dimensionUrl"
                  render={({ field }) => (
                     <FileUploadField
                      field={field}
                      label="Dimension Drawing"
                      isSubmitting={isSubmitting}
                      onFileChange={handleFileUpload}
                      onClear={clearFile}
                      fileRef={dimensionUrlFileRef}
                      icon={Ruler}
                    />
                  )}
                />
                 <FormField
                  control={form.control}
                  name="photometricChartUrl"
                  render={({ field }) => (
                     <FileUploadField
                      field={field}
                      label="Photometric Chart"
                      isSubmitting={isSubmitting}
                      onFileChange={handleFileUpload}
                      onClear={clearFile}
                      fileRef={photometricChartUrlFileRef}
                      icon={BarChart3}
                    />
                  )}
                />
              </CardContent>
            </Card>
            <Card>
              <CardHeader><CardTitle>Document URLs</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                 <FormField control={form.control} name="datasheetUrl" render={({ field }) => (
                    <FormItem><FormLabel>Datasheet URL</FormLabel><FormControl><Input type="url" placeholder="https://..." {...field} value={field.value ?? ''} /></FormControl><FormMessage /></FormItem>
                  )}/>
                  <FormField control={form.control} name="iesFileUrl" render={({ field }) => (
                    <FormItem><FormLabel>IES File URL</FormLabel><FormControl><Input type="url" placeholder="https://..." {...field} value={field.value ?? ''} /></FormControl><FormMessage /></FormItem>
                  )}/>
                  <FormField control={form.control} name="revitFileUrl" render={({ field }) => (
                    <FormItem><FormLabel>Revit File URL</FormLabel><FormControl><Input type="url" placeholder="https://..." {...field} value={field.value ?? ''} /></FormControl><FormMessage /></FormItem>
                  )}/>
                   <FormField control={form.control} name="installationGuide" render={({ field }) => (
                    <FormItem><FormLabel>Installation Guide URL</FormLabel><FormControl><Input type="url" placeholder="https://..." {...field} value={field.value ?? ''} /></FormControl><FormMessage /></FormItem>
                  )}/>
              </CardContent>
            </Card>
          </div>
        </div>
        {showSubmitButton && (
            <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => router.back()}>Cancel</Button>
            <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                {initialProduct ? 'Update' : 'Create'} Product
            </Button>
            </div>
        )}
      </form>
    </Form>
  );
}
