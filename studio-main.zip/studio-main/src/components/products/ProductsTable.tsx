
'use client';

import * as React from 'react';
import Image from 'next/image';
import Link from 'next/link';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Button } from '@/components/ui/button';
import { FileDown, Trash2, ExternalLink } from 'lucide-react';
import ProductActions from './ProductActions';
import type { Product } from '@/lib/definitions';
import { useToast } from '@/hooks/use-toast';
import { useProducts } from '@/context/ProductContext';
import { getDirectImageUrl, isGoogleDriveFolder } from '@/lib/utils';
import { useUser } from '@/firebase';
import * as xlsx from 'xlsx';

type ProductsTableProps = {
  products: Product[];
  variant?: 'default' | 'compact';
};

export default function ProductsTable({
  products,
  variant = 'default',
}: ProductsTableProps) {
  const { toast } = useToast();
  const { products: allProducts, deleteProduct } = useProducts();
  const [selectedRows, setSelectedRows] = React.useState<string[]>([]);
  const { user: appUser } = useUser();

  const handleSelectAll = (checked: boolean | 'indeterminate') => {
    if (checked === true) {
      setSelectedRows(products.map((p) => p.id));
    } else {
      setSelectedRows([]);
    }
  };

  const handleRowSelect = (id: string, checked: boolean) => {
    if (checked) {
      setSelectedRows((prev) => [...prev, id]);
    } else {
      setSelectedRows((prev) => prev.filter((rowId) => rowId !== id));
    }
  };

  const isAllSelected =
    selectedRows.length > 0 && selectedRows.length === products.length;
  const isIndeterminate =
    selectedRows.length > 0 && selectedRows.length < products.length;

  const showCheckboxes = variant === 'default';

  const handleBulkAction = (action: 'export' | 'delete') => {
    if (selectedRows.length === 0) {
      toast({
        variant: 'destructive',
        title: 'No products selected',
        description: 'Please select at least one product to perform this action.',
      });
      return;
    }

    if (action === 'delete') {
      selectedRows.forEach(id => deleteProduct(id));
      toast({
        title: 'Products Deleted',
        description: `${selectedRows.length} items have been deleted.`,
      });
      setSelectedRows([]);
    } else if (action === 'export') {
      const selectedProducts = allProducts.filter(p => selectedRows.includes(p.id));
      
      // Define the headers you want in your CSV
      const headers = [
        "id", "fixtureName", "category", "subcategory", "nmw", "mountingType", "variant", "cct",
        "wattage", "beamAngle", "ipRating", "ikRating", "lumen", "description", "colors", "cri",
        "drivingCurrent", "efficacy", "efficiency", "ugr", "bcr", "binning", "lifetime", "driverType",
        "thd", "tunable", "dimmable", "integratedRemote", "weight", "status", "gunioReport",
        "iesFileUrl", "revitFileUrl", "datasheetUrl", "installationGuide", "dimensionUrl",
        "photometricChartUrl", "imageUrl", "remarks", "testedDate", "lastUpdated", "createdAt",
        "priceINR", "priceUSD", "priceAED", "priceAUD", "priceGBP"
      ];
      
      const dataToExport = selectedProducts.map(p => {
        const row: any = {};
        headers.forEach(header => {
          row[header] = p[header as keyof Product] ?? '';
        });
        return row;
      });

      const worksheet = xlsx.utils.json_to_sheet(dataToExport, { header: headers });
      const workbook = xlsx.utils.book_new();
      xlsx.utils.book_append_sheet(workbook, worksheet, 'Selected Products');
      
      // Generate and download the CSV file
      xlsx.writeFile(workbook, `Plus Light Tech_Products_Export_${new Date().toISOString().split('T')[0]}.xlsx`);

      toast({
        title: 'Export Successful',
        description: `${selectedProducts.length} products have been exported.`,
      });
    }
  }

  return (
    <div className="w-full">
      {showCheckboxes && selectedRows.length > 0 && (
        <div className="mb-4 flex items-center gap-2">
          <span className="text-sm text-muted-foreground">
            {selectedRows.length} selected
          </span>
          <Button variant="outline" size="sm" onClick={() => handleBulkAction('export')}>
            <FileDown className="mr-2 h-4 w-4" />
            Export
          </Button>
          {appUser?.role === 'Admin' && (
            <Button variant="destructive" size="sm" onClick={() => handleBulkAction('delete')}>
              <Trash2 className="mr-2 h-4 w-4" />
              Delete
            </Button>
          )}
        </div>
      )}
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              {showCheckboxes && (
                <TableCell className="w-[50px]">
                  <Checkbox
                    checked={isAllSelected || isIndeterminate}
                    onCheckedChange={handleSelectAll}
                    aria-label="Select all"
                  />
                </TableCell>
              )}
              <TableHead className="w-[300px]">Product</TableHead>
              <TableHead>Category</TableHead>
              <TableHead>Mounting Type</TableHead>
              <TableHead>Variant</TableHead>
              <TableHead>CCT</TableHead>
              <TableHead>Lumen</TableHead>
              <TableHead>Beam Angle</TableHead>
              <TableHead>Wattage</TableHead>
              <TableHead>Driving Current</TableHead>
              <TableHead>Price (INR)</TableHead>
              <TableHead>Status</TableHead>
              {variant === 'default' && (
                <TableHead className="text-right">Actions</TableHead>
              )}
            </TableRow>
          </TableHeader>
          <TableBody>
            {products.map((product) => (
              <TableRow
                key={product.id}
                data-state={selectedRows.includes(product.id) && 'selected'}
              >
                {showCheckboxes && (
                  <TableCell>
                    <Checkbox
                      checked={selectedRows.includes(product.id)}
                      onCheckedChange={(checked) =>
                        handleRowSelect(product.id, !!checked)
                      }
                      aria-label={`Select row ${product.id}`}
                    />
                  </TableCell>
                )}
                <TableCell className="font-medium">
                  <Link href={`/products/${product.id}`} className="flex items-center gap-3 group">
                    {product.imageUrl && isGoogleDriveFolder(product.imageUrl) ? (
                       <div
                          className="inline-flex h-[48px] w-[64px] items-center justify-center gap-1 rounded-md bg-secondary text-secondary-foreground group-hover:bg-secondary/80 text-xs text-center"
                          title={`View folder for ${product.fixtureName}`}
                        >
                          <ExternalLink className="h-4 w-4" />
                          Folder
                        </div>
                    ) : product.imageUrl ? (
                      <Image
                        src={getDirectImageUrl(product.imageUrl)}
                        alt={product.fixtureName}
                        width={64}
                        height={48}
                        className="rounded-md object-cover"
                        data-ai-hint={product.imageHint}
                        onError={(e) => { e.currentTarget.src = 'https://picsum.photos/seed/placeholder/64/48'; }}
                      />
                    ) : (
                      <div className="h-[48px] w-[64px] rounded-md bg-secondary flex items-center justify-center text-xs text-muted-foreground">No Image</div>
                    )}

                    <div className="flex flex-col">
                      <span className="group-hover:underline">
                        {product.fixtureName}
                      </span>
                      <span className="text-xs text-muted-foreground">{product.variant}</span>
                    </div>
                  </Link>
                </TableCell>
                <TableCell>
                  <Badge variant="secondary">{product.category}</Badge>
                </TableCell>
                <TableCell>{product.mountingType}</TableCell>
                <TableCell>{product.variant}</TableCell>
                <TableCell>{product.cct}</TableCell>
                <TableCell>{product.lumen}</TableCell>
                <TableCell>{product.beamAngle ? `${product.beamAngle}°` : ''}</TableCell>
                <TableCell>{product.wattage ? `${product.wattage}W` : ''}</TableCell>
                <TableCell>{product.drivingCurrent ? `${product.drivingCurrent}mA` : ''}</TableCell>
                <TableCell>{product.priceINR ? `₹${product.priceINR.toLocaleString('en-IN')}` : '-'}</TableCell>
                <TableCell>
                  <Badge variant={product.status === 'Available' ? 'secondary' : 'outline'}>
                    {product.status}
                  </Badge>
                </TableCell>
                {variant === 'default' && (
                  <TableCell className="text-right">
                    <ProductActions product={product} />
                  </TableCell>
                )}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
