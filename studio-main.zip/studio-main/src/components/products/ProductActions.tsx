
'use client';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import {
  MoreHorizontal,
  Edit,
  Trash2,
  FileText,
  Eye,
  Loader2,
} from 'lucide-react';
import Link from 'next/link';
import type { Product } from '@/lib/definitions';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';
import { useState } from 'react';
import { useProducts } from '@/context/ProductContext';
import { useUser } from '@/firebase';
import { generateProductPdf } from '@/lib/pdf';

export default function ProductActions({ product }: { product: Product }) {
  const { toast } = useToast();
  const { deleteProduct } = useProducts();
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const { user: appUser } = useUser();

  const canEdit = appUser?.role === 'Admin' || appUser?.role === 'Editor';
  const canDelete = appUser?.role === 'Admin';

  const handleGenerateDatasheet = async () => {
    setIsGeneratingPdf(true);
    toast({
      title: 'Generating PDF...',
      description: `Please wait while we create the datasheet for "${product.fixtureName}".`,
    });
    try {
      await generateProductPdf(product);
      toast({
        title: 'PDF Generated',
        description: `The datasheet for "${product.fixtureName}" has been downloaded.`,
      });
    } catch (error) {
      console.error('PDF generation failed:', error);
      toast({
        variant: 'destructive',
        title: 'PDF Generation Failed',
        description: 'Could not generate the PDF. Please try again.',
      });
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const handleDelete = () => {
    deleteProduct(product.id);
    toast({
      title: 'Product Deleted',
      description: `The product "${product.fixtureName}" has been deleted.`,
    });
  };

  return (
    <>
      <AlertDialog>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-8 w-8 p-0">
              <span className="sr-only">Open menu</span>
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem asChild>
                <Link href={`/products/${product.id}`}>
                  <Eye className="mr-2 h-4 w-4" />
                  View
                </Link>
              </DropdownMenuItem>
            {canEdit && (
              <DropdownMenuItem asChild>
                <Link href={`/products/${product.id}/edit`}>
                  <Edit className="mr-2 h-4 w-4" />
                  Edit
                </Link>
              </DropdownMenuItem>
            )}
            <DropdownMenuItem onClick={handleGenerateDatasheet} disabled={isGeneratingPdf}>
              {isGeneratingPdf ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <FileText className="mr-2 h-4 w-4" />}
              <span>Generate Datasheet</span>
            </DropdownMenuItem>
            {canDelete && (
              <>
                <DropdownMenuSeparator />
                <AlertDialogTrigger asChild>
                  <DropdownMenuItem className="text-destructive focus:text-destructive">
                    <Trash2 className="mr-2 h-4 w-4" />
                    Delete
                  </DropdownMenuItem>
                </AlertDialogTrigger>
              </>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the
              product &quot;{product.fixtureName}&quot;.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
