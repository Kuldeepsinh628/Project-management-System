
'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { useState } from 'react';
import { Eye, EyeOff, Loader2 } from 'lucide-react';
import type { User } from '@/lib/definitions';
import { USERS as placeholderUsers } from '@/lib/placeholder-data';

type UserWithPassword = User & { password?: string };

const passwordFormSchema = z.object({
  currentPassword: z.string().min(1, { message: 'Please enter your current password.' }),
  newPassword: z.string().min(8, { message: 'New password must be at least 8 characters.' }),
  confirmPassword: z.string(),
}).refine(data => data.newPassword === data.confirmPassword, {
  message: "New passwords don't match",
  path: ['confirmPassword'],
});

type PasswordFormValues = z.infer<typeof passwordFormSchema>;

export default function PasswordForm() {
  const { toast } = useToast();
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<PasswordFormValues>({
    resolver: zodResolver(passwordFormSchema),
    defaultValues: {
      currentPassword: '',
      newPassword: '',
      confirmPassword: '',
    },
  });

  function onSubmit(data: PasswordFormValues) {
    setIsSubmitting(true);
    
    try {
      const loggedInUserString = sessionStorage.getItem('loggedInUser');
      if (!loggedInUserString) {
        toast({ variant: "destructive", title: 'Error', description: 'No user is logged in.' });
        return;
      }
      const loggedInUser: User = JSON.parse(loggedInUserString);

      const storedUsersString = localStorage.getItem('users');
      const storedUsers: UserWithPassword[] = storedUsersString ? JSON.parse(storedUsersString) : placeholderUsers;
      
      const userIndex = storedUsers.findIndex(u => u.id === loggedInUser.id);

      if (userIndex === -1) {
        toast({ variant: "destructive", title: 'Error', description: 'Could not find your user account.' });
        return;
      }
      
      const userToUpdate = storedUsers[userIndex];
      // Default placeholder users have 'password' as their password.
      const expectedPassword = userToUpdate.password || 'password';

      if (data.currentPassword !== expectedPassword) {
        toast({ variant: "destructive", title: 'Incorrect Password', description: 'The current password you entered is incorrect.' });
        return;
      }
      
      // Update the password
      storedUsers[userIndex].password = data.newPassword;
      localStorage.setItem('users', JSON.stringify(storedUsers));
      
      // Also update session storage if needed, to keep it in sync
      const updatedSessionUser = { ...loggedInUser, password: data.newPassword };
      sessionStorage.setItem('loggedInUser', JSON.stringify(updatedSessionUser));

      toast({
        title: 'Password Updated',
        description: 'Your password has been changed successfully.',
      });
      form.reset();

    } catch (error) {
       toast({
        variant: "destructive",
        title: 'An error occurred',
        description: 'Failed to update password. Please try again.',
      });
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Change Password</CardTitle>
        <CardDescription>
          Update your password here. Remember to choose a strong one.
        </CardDescription>
      </CardHeader>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <CardContent className="space-y-4">
            <FormField
              control={form.control}
              name="currentPassword"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Current Password</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input type={showCurrentPassword ? 'text' : 'password'} {...field} disabled={isSubmitting} />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-1 top-1/2 h-7 w-7 -translate-y-1/2 text-muted-foreground"
                        onClick={() => setShowCurrentPassword(prev => !prev)}
                        disabled={isSubmitting}
                      >
                        {showCurrentPassword ? <EyeOff /> : <Eye />}
                        <span className="sr-only">{showCurrentPassword ? 'Hide password' : 'Show password'}</span>
                      </Button>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="newPassword"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>New Password</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input type={showNewPassword ? 'text' : 'password'} {...field} disabled={isSubmitting} />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-1 top-1/2 h-7 w-7 -translate-y-1/2 text-muted-foreground"
                        onClick={() => setShowNewPassword(prev => !prev)}
                        disabled={isSubmitting}
                      >
                        {showNewPassword ? <EyeOff /> : <Eye />}
                        <span className="sr-only">{showNewPassword ? 'Hide password' : 'Show password'}</span>
                      </Button>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="confirmPassword"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Confirm New Password</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input type={showConfirmPassword ? 'text' : 'password'} {...field} disabled={isSubmitting} />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-1 top-1/2 h-7 w-7 -translate-y-1/2 text-muted-foreground"
                        onClick={() => setShowConfirmPassword(prev => !prev)}
                        disabled={isSubmitting}
                      >
                        {showConfirmPassword ? <EyeOff /> : <Eye />}
                        <span className="sr-only">{showConfirmPassword ? 'Hide password' : 'Show password'}</span>
                      </Button>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>
          <CardFooter className="border-t px-6 py-4">
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Update Password
            </Button>
          </CardFooter>
        </form>
      </Form>
    </Card>
  );
}
