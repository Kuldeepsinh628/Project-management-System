'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { useEffect } from 'react';

type Attribute = {
  id: string;
  name: string;
  productCount?: number;
};

const attributeFormSchema = z.object({
  name: z.string().min(2, { message: 'Name must be at least 2 characters.' }),
});

type AttributeFormValues = z.infer<typeof attributeFormSchema>;

type AttributeFormDialogProps = {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  attribute: Attribute | null;
  onSave: (name: string) => void;
  attributeTypeName: string;
};

export default function AttributeFormDialog({ isOpen, setIsOpen, attribute, onSave, attributeTypeName }: AttributeFormDialogProps) {
  const form = useForm<AttributeFormValues>({
    resolver: zodResolver(attributeFormSchema),
  });

  useEffect(() => {
    if (isOpen) {
      if (attribute) {
        form.reset({
          name: attribute.name,
        });
      } else {
        form.reset({
          name: '',
        });
      }
    }
  }, [attribute, form, isOpen]);

  const onSubmit = (data: AttributeFormValues) => {
    onSave(data.name);
    setIsOpen(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{attribute ? `Edit ${attributeTypeName}` : `Add New ${attributeTypeName}`}</DialogTitle>
          <DialogDescription>
            {attribute ? `Update the name for this ${attributeTypeName.toLowerCase()}.` : `Enter the name for the new ${attributeTypeName.toLowerCase()}.`}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 py-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Name</FormLabel>
                  <FormControl>
                    <Input placeholder={`${attributeTypeName} name`} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>
                Cancel
              </Button>
              <Button type="submit">Save</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
