
'use client';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { MoreHorizontal, PlusCircle, Edit, Trash2 } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '../ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { useState, useEffect } from 'react';
import AttributeFormDialog from './AttributeFormDialog';
import { useToast } from '@/hooks/use-toast';

type Attribute = {
  id: string;
  name: string;
  productCount?: number;
};

type AttributesTableProps = {
  title: string;
  data: Attribute[];
};

const getStorageKey = (title: string) => `attributes_${title.toLowerCase().replace(/[^a-z0-9]/g, '_')}`;

export default function AttributesTable({ title, data: initialData }: AttributesTableProps) {
  const [data, setData] = useState<Attribute[]>([]);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingAttribute, setEditingAttribute] = useState<Attribute | null>(null);
  const { toast } = useToast();
  const hasCount = title === 'Categories';
  const storageKey = getStorageKey(title);
  
  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        const storedData = window.localStorage.getItem(storageKey);
        if (storedData) {
          setData(JSON.parse(storedData));
        } else {
          // If nothing in storage, initialize with placeholder data and save it
          setData(initialData);
          window.localStorage.setItem(storageKey, JSON.stringify(initialData));
        }
      } catch (error) {
        console.error(`Failed to load ${title} from localStorage`, error);
        setData(initialData);
      }
    }
  }, [initialData, storageKey, title]);

  const updateAndPersistData = (newData: Attribute[]) => {
    setData(newData);
     if (typeof window !== 'undefined') {
      window.localStorage.setItem(storageKey, JSON.stringify(newData));
    }
  };

  const handleAdd = () => {
    setEditingAttribute(null);
    setIsFormOpen(true);
  };

  const handleEdit = (attribute: Attribute) => {
    setEditingAttribute(attribute);
    setIsFormOpen(true);
  };

  const handleDelete = (attributeId: string) => {
    const newData = data.filter((item) => item.id !== attributeId);
    updateAndPersistData(newData);
    toast({
      title: 'Attribute Deleted',
      description: 'The attribute has been successfully deleted.',
    });
  };

  const handleSave = (attributeName: string) => {
    if (editingAttribute) {
      const newData = data.map((item) => (item.id === editingAttribute.id ? { ...item, name: attributeName } : item));
      updateAndPersistData(newData);
      toast({
        title: 'Attribute Updated',
        description: `The attribute has been updated to "${attributeName}".`,
      });
    } else {
      const newAttribute = {
        id: `${title.toLowerCase().slice(0, 3)}-${Date.now()}`,
        name: attributeName,
        ...(hasCount && { productCount: 0 }),
      };
      const newData = [...data, newAttribute];
      updateAndPersistData(newData);
      toast({
        title: 'Attribute Added',
        description: `The attribute "${attributeName}" has been added.`,
      });
    }
    setEditingAttribute(null);
  };

  return (
    <>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>{title}</CardTitle>
          <Button variant="ghost" size="sm" onClick={handleAdd}>
            <PlusCircle className="mr-2 h-4 w-4" />
            Add New
          </Button>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  {hasCount && <TableHead>Products</TableHead>}
                  <TableHead className="w-[50px] text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="font-medium">{item.name}</TableCell>
                    {hasCount && <TableCell>{item.productCount}</TableCell>}
                    <TableCell className="text-right">
                       <AlertDialog>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleEdit(item)}>
                              <Edit className="mr-2 h-4 w-4" />
                              Edit
                            </DropdownMenuItem>
                            <AlertDialogTrigger asChild>
                              <DropdownMenuItem className="text-destructive focus:text-destructive">
                                <Trash2 className="mr-2 h-4 w-4" />
                                Delete
                              </DropdownMenuItem>
                            </AlertDialogTrigger>
                          </DropdownMenuContent>
                        </DropdownMenu>
                        <AlertDialogContent>
                            <AlertDialogHeader>
                                <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                                <AlertDialogDescription>
                                This action cannot be undone. This will permanently delete the
                                attribute &quot;{item.name}&quot;.
                                </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={() => handleDelete(item.id)}>Delete</AlertDialogAction>
                            </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
      <AttributeFormDialog
        isOpen={isFormOpen}
        setIsOpen={setIsFormOpen}
        attribute={editingAttribute}
        onSave={handleSave}
        attributeTypeName={title.slice(0,-1)}
      />
    </>
  );
}
