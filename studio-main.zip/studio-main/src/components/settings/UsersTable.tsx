'use client';
import type { User } from '@/lib/definitions';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '../ui/button';
import { PlusCircle, Info } from 'lucide-react';
import { useState, useEffect } from 'react';
import UserFormDialog from './UserFormDialog';
import { useToast } from '@/hooks/use-toast';
import UserActions from './UserActions';
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from "@/components/ui/alert"

const saveUsersToStorage = (users: User[]) => {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem('users', JSON.stringify(users));
  } catch (error) {
    console.error("Failed to save users to localStorage", error);
  }
};

export default function UsersTable({ initialUsers: serverInitialUsers = [] }: { initialUsers: User[] }) {
  const [users, setUsers] = useState<User[]>(serverInitialUsers);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    setUsers(serverInitialUsers);
  }, [serverInitialUsers]);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      saveUsersToStorage(users);
    }
  }, [users]);


  const handleAddUser = () => {
    setEditingUser(null);
    setIsFormOpen(true);
  };

  const handleEditUser = (user: User) => {
    setEditingUser(user);
    setIsFormOpen(true);
  };

  const handleDeleteUser = (userId: string) => {
    setUsers(users.filter((user) => user.id !== userId));
    toast({
      title: 'User Deleted',
      description: 'The user has been successfully deleted.',
    });
  };

  const handleSaveUser = (user: User) => {
    if (editingUser) {
      setUsers(users.map((u) => (u.id === user.id ? user : u)));
      toast({
        title: 'User Updated',
        description: `${user.name}'s information has been updated.`,
      });
    } else {
      const newUser = { ...user, id: `usr-${Date.now()}` };
      setUsers([...users, newUser]);
      toast({
        title: 'User Added',
        description: `${user.name} has been added.`,
      });
    }
  };

  return (
    <>
      <Alert>
        <Info className="h-4 w-4" />
        <AlertTitle>User Roles & Permissions</AlertTitle>
        <AlertDescription>
          <ul className="list-disc pl-5 space-y-1 mt-2">
            <li><b>Admin:</b> Full control. Can manage products, users, and settings.</li>
            <li><b>Editor:</b> Can manage products and attributes, but not users.</li>
            <li><b>Viewer:</b> Read-only access. Can view products but cannot edit.</li>
          </ul>
        </AlertDescription>
      </Alert>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>User Management</CardTitle>
            <CardDescription>
              View and manage user roles across the application.
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Button onClick={handleAddUser}>
              <PlusCircle className="mr-2 h-4 w-4" />
              Add User
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>User</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead className="w-[50px] text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarImage src={user.avatarUrl} alt={user.name} />
                          <AvatarFallback>{user.name[0]}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{user.name}</p>
                          <p className="text-sm text-muted-foreground">{user.email}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={user.role === 'Admin' ? 'default' : 'secondary'}>
                        {user.role}
                      </Badge>
                    </TableCell>
                    <TableCell className='text-right'>
                      <UserActions
                        user={user}
                        onEdit={handleEditUser}
                        onDelete={handleDeleteUser}
                      />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
      <UserFormDialog
        isOpen={isFormOpen}
        setIsOpen={setIsFormOpen}
        user={editingUser}
        onSave={handleSaveUser}
      />
    </>
  );
}
