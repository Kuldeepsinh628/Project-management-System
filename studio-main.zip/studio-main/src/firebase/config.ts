export const firebaseConfig = {
  "projectId": "studio-4753428807-19271",
  "appId": "1:285365563983:web:c04e409c4cfa417426703a",
  "apiKey": "AIzaSyAFBAJg1a-0cass6YaxF8fr5S_tuXIX-0s",
  "authDomain": "studio-4753428807-19271.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "285365563983",
  "storageBucket": "studio-4753428807-19271.appspot.com"
};
