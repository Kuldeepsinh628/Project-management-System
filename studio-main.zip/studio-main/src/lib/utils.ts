
import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function getDirectImageUrl(driveUrl: string | null | undefined): string {
  const fallbackImage = 'https://picsum.photos/seed/fallback/600/400';

  if (!driveUrl || typeof driveUrl !== 'string' || driveUrl.trim() === '') {
    return fallbackImage;
  }
  
  const isExternal = driveUrl.startsWith('https://pluslighttech.com');

  if (isExternal) {
    return `/api/image-proxy?url=${encodeURIComponent(driveUrl)}`;
  }

  // If it's already a direct image or placeholder, return it.
  if (driveUrl.includes('picsum.photos') || driveUrl.startsWith('https://storage.googleapis.com') || driveUrl.startsWith('data:image')) {
    return driveUrl;
  }

  if (driveUrl.includes('drive.google.com')) {
    // Check if it's a folder link
    if (driveUrl.includes('/drive/folders/')) {
        return driveUrl; // Return the folder URL to be handled differently
    }

    const fileIdMatch = driveUrl.match(/\/file\/d\/([a-zA-Z0-9-_]+)/) || driveUrl.match(/id=([a-zA-Z0-9-_]+)/);
    if (fileIdMatch && fileIdMatch[1]) {
      return `https://drive.google.com/uc?export=view&id=${fileIdMatch[1]}`;
    }
  }

  // If it looks like a valid, direct image URL, return it.
  if (driveUrl.startsWith('http')) {
     try {
       new URL(driveUrl);
       return driveUrl;
     } catch (e) {
       return fallbackImage;
     }
  }
  
  // If all else fails, return the fallback.
  return fallbackImage;
}


export function isGoogleDriveFolder(url: string | null | undefined): boolean {
  if (!url || typeof url !== 'string') {
    return false;
  }
  return url.includes('drive.google.com/drive/folders/');
}


/**
 * Loads an image from a URL and converts it to a base64 string.
 * This is necessary for embedding images into the PDF with jsPDF and html2canvas.
 * @param imageUrl The URL of the image to load.
 * @returns A promise that resolves with the base64 string or null if loading fails.
 */
export function loadImageAsBase64(imageUrl: string | null | undefined): Promise<string | null> {
  return new Promise((resolve) => {
    if (!imageUrl) {
      resolve(null);
      return;
    }
    
    // If the imageUrl is already a base64 string, just return it.
    if(imageUrl.startsWith('data:image')) {
      resolve(imageUrl);
      return;
    }

    // Construct an absolute URL for the API proxy
    const proxyUrl = new URL('/api/image-proxy', window.location.origin);
    proxyUrl.searchParams.set('url', imageUrl);
    const urlToFetch = proxyUrl.toString();

    fetch(urlToFetch)
      .then(response => {
        if (!response.ok) {
          throw new Error(`Failed to fetch image: ${response.statusText}`);
        }
        return response.blob();
      })
      .then(blob => {
        const reader = new FileReader();
        reader.onloadend = () => {
          resolve(reader.result as string);
        };
        reader.onerror = () => {
          console.error('Failed to read blob as data URL.');
          resolve(null);
        }
        reader.readAsDataURL(blob);
      })
      .catch(error => {
        console.error(`Image load failed for src: ${imageUrl}`, error);
        resolve(null);
      });
  });
}
