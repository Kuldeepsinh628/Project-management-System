
export type User = {
  id: string;
  name: string;
  email: string;
  avatarUrl: string;
  role: 'Admin' | 'Editor' | 'Viewer';
};

export type Category = {
  id: string;
  name: string;
  productCount: number;
};

export type SubCategory = {
  id: string;
  name:string;
}

export type Variant = {
  id: string;
  name: string;
}

export type MountingType = {
  id: string;
  name: string;
}

export type Product = {
  id: string;
  fixtureName: string;
  category: string;
  subcategory: string;
  nmw: string;
  mountingType: string;
  cct: string;
  beamAngle: string | null;
  wattage: string | null;
  variants: number;
  imageUrl: string;
  variant: string;
  ipRating: string;
  ikRating: string;
  colors: string;
  cri: string;
  drivingCurrent: string;
  lumen: string;
  efficacy: string;
  efficiency: string;
  ugr: string;
  bcr: string;
  binning: string;
  lifetime: string;
  driverType: string;
  thd: string;
  tunable: boolean;
  dimmable: boolean;
  integratedRemote: string;
  weight: string;
  status: string;
  gunioReport: string;
  iesFileUrl?: string;
  description: string;
  remarks: string;
  revitFileUrl?: string;
  datasheetUrl?: string;
  installationGuide: string;
  testedDate: string;
  lastUpdated: string;
  imageId: string;
  imageHint?: string;
  dimensionUrl?: string;
  priceINR?: number | null;
  priceUSD?: number | null;
  priceAED?: number | null;
  priceAUD?: number | null;
  priceGBP?: number | null;
  photometricChartUrl?: string;
  createdAt?: string;
  datasheetHtml?: string;
};

export type StatCard = {
  label: string;
  value: string | number;
  icon: React.ComponentType<{ className?: string }>;
  href?: string;
};

// Extended type for datasheet generation
export type ProductWithImages = Product & { 
  productImage?: string; 
  dimensionDrawing?: string; 
  photometricChart?: string;
};

    