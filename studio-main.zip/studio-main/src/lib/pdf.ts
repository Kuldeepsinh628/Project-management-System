
'use client';

import * as React from 'react';
import * as ReactDOMServer from 'react-dom/server';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { ProductDataSheet } from '@/components/datasheet/ProductDataSheet';
import { type Product } from '@/lib/definitions';
import { getDirectImageUrl, isGoogleDriveFolder, loadImageAsBase64 } from './utils';

export const generateProductPdf = async (product: Product) => {
  // 1. Load images and convert them to base64, skipping folder URLs
  const [mainImage, dimensionImage, photometricImage] = await Promise.all([
    isGoogleDriveFolder(product.imageUrl) ? null : loadImageAsBase64(getDirectImageUrl(product.imageUrl)),
    isGoogleDriveFolder(product.dimensionUrl) ? null : loadImageAsBase64(getDirectImageUrl(product.dimensionUrl)),
    isGoogleDriveFolder(product.photometricChartUrl) ? null : loadImageAsBase64(getDirectImageUrl(product.photometricChartUrl)),
  ]);

  // 2. Render the component to an HTML string with base64 images
  const datasheetHtml = ReactDOMServer.renderToString(
    React.createElement(ProductDataSheet, {
      product: product,
      imageUrls: {
        main: mainImage,
        dimension: dimensionImage,
        photometric: photometricImage,
      },
    })
  );

  // 3. Create a temporary container to render the HTML
  const container = document.createElement('div');
  container.style.position = 'absolute';
  container.style.left = '-9999px';
  container.style.width = '210mm'; // Set width for accurate rendering
  container.innerHTML = datasheetHtml;
  document.body.appendChild(container);

  const datasheetElement = container.querySelector<HTMLElement>('#datasheet-container');
  if (!datasheetElement) {
    document.body.removeChild(container);
    throw new Error('Datasheet element not found');
  }

  try {
    // 4. Use html2canvas to capture the element
    const canvas = await html2canvas(datasheetElement, {
      scale: 3, // Higher scale for better quality
      useCORS: true,
      allowTaint: true,
    });

    // 5. Generate PDF
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = pdf.internal.pageSize.getHeight();

    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
    pdf.save(`${product.fixtureName || 'datasheet'}.pdf`);
  } finally {
    // 6. Clean up the temporary container
    document.body.removeChild(container);
  }
};
