
'use client';

import * as React from 'react';
import * as xlsx from 'xlsx';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Upload, Loader2, Download } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useProducts } from '@/context/ProductContext';
import type { Product, Category, SubCategory, Variant, MountingType } from '@/lib/definitions';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

type Attribute = Category | SubCategory | Variant | MountingType;

// Helper to convert header to camelCase
const toCamelCase = (str: string): string => {
  if (!str) return '';
  // Convert to lower case, remove content in parentheses, then camelCase.
  return str
    .toLowerCase()
    .replace(/\s*\(.*?\)\s*/g, '') // remove text in parentheses
    .replace(/[^a-zA-Z0-9\s_/-]+/g, '') // remove special characters but keep spaces, underscores, slashes, hyphens
    .replace(/[\s_/-]+(\w)/g, (_, c) => c.toUpperCase()) // camelCase after space, underscore, slash, or hyphen
    .replace(/[\s_/-]/g, ''); // remove any remaining spaces, underscores, slashes, or hyphens
};

const REQUIRED_HEADERS = ['fixtureName'];

// Helper to update attributes in localStorage
const updateAttributes = (title: string, newValues: string[]) => {
  if (typeof window === 'undefined') return;

  const storageKey = `attributes_${title.toLowerCase().replace(/[^a-z0-9]/g, '_')}`;
  try {
    const storedData = window.localStorage.getItem(storageKey);
    const existingAttributes: Attribute[] = storedData ? JSON.parse(storedData) : [];
    const existingNames = new Set(existingAttributes.map(attr => attr.name.toLowerCase()));

    const attributesToAdd = newValues
      .filter(name => !existingNames.has(name.toLowerCase()))
      .map(name => ({
        id: `${title.toLowerCase().slice(0, 3)}-${Date.now()}-${Math.random()}`,
        name: name,
        ...(title === 'Categories' && { productCount: 0 }),
      }));

    if (attributesToAdd.length > 0) {
      const updatedAttributes = [...existingAttributes, ...attributesToAdd];
      window.localStorage.setItem(storageKey, JSON.stringify(updatedAttributes));
    }
  } catch (error) {
    console.error(`Failed to update ${title} attributes in localStorage`, error);
  }
};


export default function ImportPage() {
  const { toast } = useToast();
  const { addProductsBatch } = useProducts();
  const [file, setFile] = React.useState<File | null>(null);
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const [fileName, setFileName] = React.useState('');
  const [isLoading, setIsLoading] = React.useState(false);
  const [importResult, setImportResult] = React.useState<{ successCount: number; failedCount: number } | null>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (selectedFile) {
      if (
        selectedFile.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
        selectedFile.type === 'text/csv'
      ) {
        setFile(selectedFile);
        setFileName(selectedFile.name);
      } else {
        toast({
            variant: "destructive",
            title: "Invalid File Type",
            description: "Please upload an Excel (.xlsx) or CSV (.csv) file.",
        });
      }
    }
  };

  const handleImport = async () => {
    if (!file) {
      toast({
        variant: "destructive",
        title: "No File Selected",
        description: "Please select a file to import.",
      });
      return;
    }
    
    setIsLoading(true);

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = xlsx.read(data, { type: 'array', cellDates: true });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        
        const jsonFromSheet = xlsx.utils.sheet_to_json(worksheet, { header: 1, defval: "" });
        
        if (jsonFromSheet.length < 2) {
             toast({
                variant: 'destructive',
                title: 'Empty or Invalid File',
                description: 'The file must contain a header row and at least one data row.',
            });
            setIsLoading(false);
            return;
        }

        const rawHeaders: string[] = (jsonFromSheet[0] as any[]).map(h => String(h || ''));
        const camelCaseHeaders = rawHeaders.map(header => toCamelCase(header));

        const missingHeaders = REQUIRED_HEADERS.filter(
            (requiredHeader) => !camelCaseHeaders.includes(requiredHeader)
        );

        if (missingHeaders.length > 0) {
            toast({
                variant: 'destructive',
                title: 'Missing Required Headers',
                description: `Your file is missing the following required columns: ${missingHeaders.join(', ')}.`,
            });
            setIsLoading(false);
            return;
        }
        
        const headerMap = Object.fromEntries(rawHeaders.map((h, i) => [h, camelCaseHeaders[i]]));
        
        const dataRows = xlsx.utils.sheet_to_json(worksheet, { defval: "" , cellDates: true}) as any[];

        const processedData = dataRows
          .map(row => {
            const rowData: { [key:string]: any } = {};
            for (const originalHeader in row) {
              const camelCaseHeader = headerMap[originalHeader];
              if (camelCaseHeader) {
                  const cellValue = row[originalHeader];
                  // Ensure null/undefined become empty strings, not "null"/"undefined"
                   rowData[camelCaseHeader] = cellValue !== null && cellValue !== undefined ? String(cellValue) : '';
              }
            }
            return rowData;
          })
          .filter(row => Object.values(row).some(val => val !== ""));

        if (processedData.length === 0) {
            toast({
                variant: 'destructive',
                title: 'No Data Found',
                description: 'No data rows were found in the file after the header.',
            });
            setIsLoading(false);
            return;
        }
        
        // Extract and update attributes
        const newCategories = [...new Set(processedData.map(p => p.category).filter(Boolean))];
        const newSubCategories = [...new Set(processedData.map(p => p.subcategory).filter(Boolean))];
        const newVariants = [...new Set(processedData.map(p => p.variant).filter(Boolean))];
        const newMountingTypes = [...new Set(processedData.map(p => p.mountingType).filter(Boolean))];

        updateAttributes('Categories', newCategories);
        updateAttributes('Sub-Categories', newSubCategories);
        updateAttributes('Variants', newVariants);
        updateAttributes('Mounting Types', newMountingTypes);
        
        const newProducts: Omit<Product, 'id' | 'lastUpdated' | 'imageId'>[] = processedData.map(row => ({
            fixtureName: row.fixtureName || '',
            category: row.category || '',
            subcategory: row.subcategory || '',
            nmw: row.nmw || '',
            mountingType: row.mountingType || '',
            cct: row.cct || '',
            beamAngle: row.beamAngle || null,
            wattage: row.wattage || null,
            variants: 1,
            imageUrl: row.imageUrl || 'https://picsum.photos/seed/new-product/600/400',
            variant: row.variant || '',
            ipRating: row.ipRating || '',
            ikRating: row.ikRating || '',
            colors: row.colors || '',
            cri: row.cri || '',
            drivingCurrent: row.drivingCurrent || '',
            lumen: row.lumenFlux || row.lumen || '',
            efficacy: row.efficacy || '',
            efficiency: row.efficiency || '',
            ugr: row.ugr || '',
            bcr: row.bcr || '',
            binning: row.binning || '',
            lifetime: row.lifetime || '',
            driverType: row.driverType || '',
            thd: row.thd || '',
            tunable: ['true', '1', 'yes'].includes(String(row.tunable).toLowerCase()),
            dimmable: ['true', '1', 'yes'].includes(String(row.dimmable).toLowerCase()),
            integratedRemote: row.integratedRemote || '',
            weight: row.weight || '',
            status: row.status || 'Pending Approval',
            gunioReport: row.gunioReport || '',
            iesFileUrl: row.iesFileUrl || '',
            description: row.description || '',
            remarks: row.remarks || '',
            revitFileUrl: row.revitFileUrl || '',
            installationGuide: row.installationGuide || '',
            testedDate: row.testedDate || '',
            datasheetUrl: row.datasheetUrl || '',
            dimensionUrl: row.dimensionUrl || '',
            photometricChartUrl: row.photometricChartUrl || '',
            priceINR: row.inr ? parseFloat(row.inr) : null,
            priceUSD: row.usd ? parseFloat(row.usd) : null,
            priceAED: row.aed ? parseFloat(row.aed) : null,
            priceAUD: row.aud ? parseFloat(row.aud) : null,
            priceGBP: row.gbp ? parseFloat(row.gbp) : null,
        }));

        await addProductsBatch(newProducts as any); // any cast because of missing fields in Omit
        
        setImportResult({ successCount: newProducts.length, failedCount: 0 });

      } catch (error) {
        console.error("File processing error:", error);
        toast({
            variant: "destructive",
            title: "Import Failed",
            description: "An error occurred while processing your file. Please check the file format and try again.",
        });
      } finally {
        setIsLoading(false);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const downloadTemplate = () => {
    const headers = [
      "Fixture Name", "Category", "Subcategory", "NMW", "Mounting Type", "Variant", 
      "IP Rating", "IK Rating", "Colors", "CCT", "CRI", "Wattage", "Driving Current", "Lumen Flux", 
      "Efficacy", "Efficiency", "Beam Angle", "UGR", "BCR", "Binning", "Lifetime", 
      "Driver Type", "THD", "Tunable", "Dimmable", "Integrated Remote", "Weight", 
      "Status", "Gunio Report", "IES File URL", "Revit File URL", "Installation Guide", "Datasheet URL", "Dimension URL", "Photometric Chart URL",
      "Description", "Remarks", "Image URL", "Tested Date", "INR", "USD", "AED", "AUD", "GBP"
    ];
    const ws = xlsx.utils.aoa_to_sheet([headers]);
    const wb = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(wb, ws, "ProductTemplate");
    xlsx.writeFile(wb, "ProductTemplate.xlsx");
  };

  const closeResultDialog = () => {
      setImportResult(null);
      setFile(null);
      setFileName('');
      if (fileInputRef.current) {
          fileInputRef.current.value = '';
      }
  }

  return (
    <div className="flex flex-col gap-8">
      <h1 className="text-3xl font-bold">Excel Bulk Import</h1>

      <Card>
        <CardHeader>
          <CardTitle>Upload Product Data</CardTitle>
          <CardDescription>
            Upload an Excel (.xlsx) or CSV (.csv) file to bulk-add products.
            Please ensure your file follows the required template format. The 'Fixture Name' is the only mandatory field.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
            <div className="grid w-full max-w-sm items-center gap-1.5">
                <Label htmlFor="product-file">Product File</Label>
                <Input ref={fileInputRef} id="product-file" type="file" accept=".xlsx, .csv" onChange={handleFileChange} disabled={isLoading} />
                {fileName && <p className="text-sm text-muted-foreground">Selected: {fileName}</p>}
            </div>
            <div className="flex items-center gap-4">
                <Button onClick={handleImport} disabled={isLoading || !file}>
                    {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Upload className="mr-2 h-4 w-4" />}
                    {isLoading ? 'Importing...' : 'Import Products'}
                </Button>
                <Button variant="outline" onClick={downloadTemplate}><Download className="mr-2 h-4 w-4" />Download Template</Button>
            </div>
        </CardContent>
      </Card>
      
      <AlertDialog open={!!importResult} onOpenChange={() => importResult && closeResultDialog()}>
        <AlertDialogContent>
            <AlertDialogHeader>
            <AlertDialogTitle>Import Complete</AlertDialogTitle>
            <AlertDialogDescription>
                Successfully imported {importResult?.successCount} products.
                {importResult && importResult.failedCount > 0 && ` Failed to import ${importResult.failedCount} products.`}
            </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
            <AlertDialogAction onClick={closeResultDialog}>
                Close
            </AlertDialogAction>
            </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

    