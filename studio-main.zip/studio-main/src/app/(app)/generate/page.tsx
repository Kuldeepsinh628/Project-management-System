

"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import * as ReactDOMServer from "react-dom/server";
import * as React from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Save, Loader2, Download, Eye, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { ProductDataSheet } from "@/components/datasheet/ProductDataSheet";
import type { Product } from "@/lib/definitions";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { format } from "date-fns";
import { useProducts } from "@/context/ProductContext";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { generateProductPdf } from "@/lib/pdf";


const initialFormData = {
  id: '',
  fixtureName: '',
  description: '',
  lumen: '',
  drivingCurrent: '',
  wattage: '',
  efficacy: '',
  cct: '',
  cri: '',
  binning: '',
  lifetime: '',
  beamAngle: '',
  ipRating: '',
  ikRating: '',
  ugr: '',
  bcr: '',
  driverType: '',
  thd: '',
  integratedRemote: '', 
  tunable: false,
  dimmable: false,
  weight: '',
  category: '',
  subcategory: '',
  variant: '',
  mountingType: '',
  colors: '',
  gunioReport: '',
  imageUrl: '',
  dimensionUrl: '',
  photometricChartUrl: '',
  nmw: '',
  variants: 0,
  iesFileUrl: '',
  revitFileUrl: '',
  datasheetUrl: '',
  installationGuide: '',
  testedDate: '',
  lastUpdated: '',
  imageId: '',
  status: '',
  remarks: '',
  priceINR: null,
  priceUSD: null,
  priceAED: null,
  priceAUD: null,
  priceGBP: null,
  createdAt: '',
  efficiency: '',
  datasheetHtml: '',
};

type FormData = typeof initialFormData;

// Function to load saved datasheets from localStorage
const loadSavedDatasheets = (): Product[] => {
  if (typeof window === 'undefined') {
    return [];
  }
  try {
    const storedDatasheets = localStorage.getItem("savedDatasheets");
    if (storedDatasheets) {
      return JSON.parse(storedDatasheets);
    }
    return [];
  } catch (error) {
    console.error("Failed to access localStorage:", error);
    return [];
  }
};


// Simple debounce function
function debounce<F extends (...args: any[]) => any>(func: F, waitFor: number) {
  let timeout: ReturnType<typeof setTimeout> | null = null;

  const debounced = (...args: Parameters<F>) => {
    if (timeout !== null) {
      clearTimeout(timeout);
    }
    timeout = setTimeout(() => func(...args), waitFor);
  };

  return debounced;
}

export default function GeneratePage() {
  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [savedDatasheets, setSavedDatasheets] = useState<Product[]>([]);
  const [datasheetHtml, setDatasheetHtml] = useState<string>("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const { toast } = useToast();
  const previewRef = useRef<HTMLDivElement>(null);
  const { products } = useProducts();
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);


  useEffect(() => {
    setSavedDatasheets(loadSavedDatasheets());
  }, []);

  useEffect(() => {
    // Persist changes to localStorage whenever savedDatasheets state changes
    if (typeof window !== 'undefined' && savedDatasheets.length >= 0) {
       try {
        // Omit datasheetHtml before saving
        localStorage.setItem("savedDatasheets", JSON.stringify(savedDatasheets.map(({datasheetHtml, ...rest}) => rest)));
      } catch (error) {
        console.error("Failed to save datasheets to localStorage:", error);
        toast({
          variant: "destructive",
          title: "Storage Error",
          description: "Could not save datasheets. The browser storage might be full.",
        });
      }
    }
  }, [savedDatasheets, toast]);

  const handleGeneratePreview = useCallback(async (currentFormData: FormData) => {
    setIsGenerating(true);
    try {
      const datasheetElement = React.createElement(ProductDataSheet, { product: currentFormData as Product });
      const html = ReactDOMServer.renderToString(datasheetElement);
      setDatasheetHtml(html);
    } catch (error) {
      console.error("Error generating datasheet:", error);
      toast({
        variant: "destructive",
        title: "Generation Failed",
        description: "Could not generate the datasheet preview.",
      });
    } finally {
      setIsGenerating(false);
    }
  }, [toast]);
  
  const debouncedGeneratePreview = useRef(debounce(handleGeneratePreview, 300)).current;

  useEffect(() => {
    if (formData.fixtureName || selectedProductId) {
      debouncedGeneratePreview(formData);
    } else {
      setDatasheetHtml(""); 
    }
  }, [formData, debouncedGeneratePreview, selectedProductId]);

  useEffect(() => {
    if (selectedProductId) {
      const product = products.find(p => p.id === selectedProductId);
      if (product) {
        setFormData(product as unknown as FormData);
      }
    } else {
      setFormData(initialFormData);
    }
  }, [selectedProductId, products]);


  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    if (selectedProductId) setSelectedProductId(null);
    const { id, value } = e.target;
    setFormData((prev) => ({ ...prev, [id]: value }));
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (selectedProductId) setSelectedProductId(null);
    const { id, files } = e.target;
    if (files && files.length > 0) {
        const file = files[0];
        const reader = new FileReader();
        reader.onloadend = () => {
            const result = reader.result as string;
            setFormData(prev => ({ ...prev, [id]: result }));
        }
        reader.readAsDataURL(file);
    }
  }
  
  const handleSaveDatasheet = () => {
    if (!datasheetHtml || !formData.fixtureName) {
        toast({
            variant: "destructive",
            title: "Cannot Save",
            description: "Please generate a preview and provide a fixture name first."
        });
        return;
    }

    // Only store the data, not the generated HTML
    const newDatasheetData: Product = {
      id: `ds-${Date.now()}`,
      fixtureName: formData.fixtureName,
      description: formData.description,
      lumen: formData.lumen,
      wattage: formData.wattage,
      efficacy: formData.efficacy,
      cct: formData.cct,
      cri: formData.cri,
      lifetime: formData.lifetime,
      beamAngle: formData.beamAngle,
      ipRating: formData.ipRating,
      driverType: formData.driverType,
      weight: formData.weight,
      category: formData.category,
      subcategory: formData.subcategory,
      variant: formData.variant,
      mountingType: formData.mountingType,
      colors: formData.colors,
      createdAt: new Date().toISOString(),
      status: formData.status || "Uploaded",
      imageUrl: formData.imageUrl,
      ikRating: formData.ikRating,
      nmw: formData.nmw,
      variants: formData.variants,
      drivingCurrent: formData.drivingCurrent,
      efficiency: formData.efficiency || '',
      ugr: formData.ugr,
      bcr: formData.bcr,
      binning: formData.binning,
      thd: formData.thd,
      tunable: formData.tunable,
      dimmable: formData.dimmable,
      integratedRemote: formData.integratedRemote,
      gunioReport: formData.gunioReport,
      remarks: formData.remarks,
      installationGuide: formData.installationGuide,
      testedDate: formData.testedDate,
      lastUpdated: new Date().toISOString(),
      imageId: formData.imageId || `img-${Date.now()}`,
      priceINR: formData.priceINR,
      priceUSD: formData.priceUSD,
      priceAED: formData.priceAED,
      priceAUD: formData.priceAUD,
      priceGBP: formData.priceGBP,
    };
    
    setSavedDatasheets(prev => [newDatasheetData, ...prev]);
    
    toast({
        title: "Datasheet Saved",
        description: `Datasheet "${newDatasheetData.fixtureName}" has been saved.`
    });

    setFormData(initialFormData);
    setSelectedProductId(null);
    setDatasheetHtml("");
  }
  
  const handleGeneratePdf = async () => {
    if (!previewRef.current || !datasheetHtml) {
        toast({
            variant: "destructive",
            title: "No Preview Available",
            description: "Please generate a preview before downloading the PDF.",
        });
        return;
    }
    setIsDownloading(true);

    const productForPdf = selectedProductId ? products.find(p => p.id === selectedProductId) : formData;

    if (!productForPdf) {
       toast({
            variant: "destructive",
            title: "Product Data Not Found",
            description: "Could not find the data to generate the PDF.",
        });
       setIsDownloading(false);
       return;
    }

    try {
        await generateProductPdf(productForPdf as Product);
    } catch (error) {
        console.error("Error generating PDF:", error);
        toast({
            variant: "destructive",
            title: "PDF Generation Failed",
            description: "An error occurred while creating the PDF.",
        });
    } finally {
        setIsDownloading(false);
    }
  }

  const handleViewDatasheet = (datasheet: Product) => {
    if (datasheet) {
      setSelectedProductId(null);
      // Generate HTML on-demand from the stored data
      const html = ReactDOMServer.renderToString(React.createElement(ProductDataSheet, { product: datasheet }));
      setDatasheetHtml(html);
      setFormData(datasheet as unknown as FormData);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      toast({
        title: "Preview Loaded",
        description: `Showing preview for ${datasheet.fixtureName}.`
      })
    }
  }

  const handleDeleteDatasheet = (datasheetId: string) => {
    setSavedDatasheets(prev => prev.filter(ds => ds.id !== datasheetId));
    toast({
        title: "Datasheet Deleted",
        description: "The saved datasheet has been removed."
    });
  }

  const formFields: {id: keyof Omit<FormData, 'priceINR'|'priceUSD'|'priceAED'|'priceAUD'|'priceGBP'|'createdAt'|'efficiency'|'datasheetHtml' | 'tunable' | 'dimmable'| 'variants'>, label: string, type?: string, span?: number}[] = [
    { id: "fixtureName", label: "Model Name", span: 2 },
    { id: "variant", label: "Variant", span: 2 },
    { id: "description", label: "Description", type: "textarea", span: 2 },
    { id: "imageUrl", label: "Product Image", type: "file", span: 1 },
    { id: "dimensionUrl", label: "Dimension Drawing", type: "file", span: 1 },
    { id: "photometricChartUrl", label: "Photometric Chart", type: "file", span: 1 },
    { id: "weight", label: "Weight", span: 1 },
    { id: "gunioReport", label: "Certificate Available", span: 1 },
    { id: "colors", label: "Colors", span: 1 },
    { id: "lumen", label: "System Lumen (lm)", span: 1 },
    { id: "wattage", label: "System Wattage (W)", span: 1 },
    { id: "drivingCurrent", label: "DC Current (mA)", span: 1 },
    { id: "efficacy", label: "Efficacy (lm/W)", span: 1 },
    { id: "cct", label: "CCT (K)", span: 1 },
    { id: "cri", label: "CRI", span: 1 },
    { id: "binning", label: "Binning", span: 1 },
    { id: "lifetime", label: "Lifetime", span: 1 },
    { id: "beamAngle", label: "Beam Angle (°)", span: 1 },
    { id: "ipRating", label: "IP Rating", span: 1 },
    { id: "ugr", label: "UGR", span: 1 },
    { id: "bcr", label: "Actual BUG", span: 1 },
    { id: "integratedRemote", label: "Input", span: 1 },
    { id: "driverType", label: "Driver Type", span: 1 },
    { id: "thd", label: "THD", span: 1 },
  ];

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="grid gap-6 lg:grid-cols-2 items-start">
        <Card>
            <CardHeader>
                <CardTitle>Manual Datasheet Generator</CardTitle>
                <CardDescription>Fill in the details manually to generate a product datasheet.</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {formFields.map(field => {
                        const isTextarea = field.type === 'textarea';
                        const isFile = field.type === 'file';
                        const containerClass = `col-span-${field.span || 1}`;

                        return (
                            <div key={field.id} className={containerClass}>
                                <Label htmlFor={field.id} className="text-sm font-medium">{field.label}</Label>
                                {isTextarea ? (
                                    <Textarea id={field.id} value={formData[field.id as keyof FormData] as string ?? ''} onChange={handleInputChange} className="mt-1" />
                                ) : isFile ? (
                                    <Input id={field.id} type="file" onChange={handleFileChange} className="mt-1" accept="image/*" />
                                ) : (
                                    <Input id={field.id} value={formData[field.id as keyof FormData] as string ?? ''} onChange={handleInputChange} className="mt-1" />
                                )}
                            </div>
                        )
                    })}
                </div>
            </CardContent>
        </Card>
      
        <Card className="sticky top-6">
            <CardHeader>
            <CardTitle className="font-headline text-2xl">
                Live Preview
            </CardTitle>
            <CardDescription>
                Your datasheet preview automatically updates here as you edit the form.
            </CardDescription>
            </CardHeader>
            <CardContent>
                <div className="border rounded-lg min-h-[600px] overflow-auto">
                <div ref={previewRef} className="bg-white">
                    {isGenerating ? (
                    <div className="flex items-center justify-center h-[600px]">
                        <div className="text-center">
                            <Loader2 className="mx-auto h-8 w-8 animate-spin text-primary mb-2" />
                            <p className="text-muted-foreground">Generating preview...</p>
                        </div>
                    </div>
                    ) : datasheetHtml ? (
                    <div dangerouslySetInnerHTML={{ __html: datasheetHtml }} />
                    ) : (
                    <div className="flex items-center justify-center h-[600px] text-muted-foreground">
                        <p>Start editing to see a preview</p>
                    </div>
                    )}
                </div>
                </div>
            </CardContent>
            <CardFooter className="flex-col items-stretch space-y-2">
                <Button onClick={handleGeneratePdf} disabled={!datasheetHtml || isGenerating || isDownloading || selectedProductId !== null} className="w-full">
                    {isDownloading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Download className="mr-2 h-4 w-4" />}
                    {isDownloading ? "Downloading..." : "Generate PDF"}
                </Button>
                <Button onClick={handleSaveDatasheet} variant="secondary" className="w-full" disabled={!datasheetHtml || selectedProductId !== null}>
                    <Save className="mr-2 h-4 w-4" />
                    Save Datasheet
                </Button>
            </CardFooter>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Saved Datasheets</CardTitle>
          <CardDescription>
            View and manage your previously generated datasheets.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {savedDatasheets.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Fixture Name</TableHead>
                  <TableHead>Date Saved</TableHead>
                  <TableHead>Wattage</TableHead>
                  <TableHead>Lumen</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {savedDatasheets.map((ds) => (
                  <TableRow key={ds.id}>
                    <TableCell className="font-medium">{ds.fixtureName}</TableCell>
                    <TableCell>{ds.createdAt ? format(new Date(ds.createdAt), "PPP") : 'N/A'}</TableCell>
                    <TableCell>{ds.wattage}W</TableCell>
                    <TableCell>{ds.lumen}</TableCell>
                    <TableCell className="text-right space-x-2">
                      <Button variant="ghost" size="sm" onClick={() => handleViewDatasheet(ds)}>
                        <Eye className="mr-2 h-4 w-4" />
                        View
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                           <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive">
                              <Trash2 className="mr-2 h-4 w-4" />
                              Delete
                            </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                            <AlertDialogHeader>
                                <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                                <AlertDialogDescription>
                                This action cannot be undone. This will permanently delete the
                                datasheet &quot;{ds.fixtureName}&quot;.
                                </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={() => handleDeleteDatasheet(ds.id)}>Delete</AlertDialogAction>
                            </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <p className="text-center text-muted-foreground py-8">
              No datasheets have been saved yet.
            </p>
          )}
        </CardContent>
      </Card>

    </div>
  );
}

    