
import Header from '@/components/layout/Header';
import SidebarNav from '@/components/layout/SidebarNav';
import { SidebarProvider, Sidebar, SidebarInset } from '@/components/ui/sidebar';
import BackToTopButton from '@/components/shared/BackToTopButton';

export default function AppLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <SidebarProvider>
      <Sidebar>
        <SidebarNav />
      </Sidebar>
      <SidebarInset>
        <div className="flex min-h-svh flex-col">
          <Header />
          <main className="flex-1 p-4 lg:p-6">{children}</main>
          <BackToTopButton />
        </div>
      </SidebarInset>
    </SidebarProvider>
  );
}
