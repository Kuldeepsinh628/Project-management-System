
'use client';

import { useState, useMemo, useEffect } from 'react';
import type { Product, Category, Variant, MountingType, SubCategory } from '@/lib/definitions';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import ProductsTable from '@/components/products/ProductsTable';
import { X } from 'lucide-react';
import { CATEGORIES as placeholderCategories, SUBCATEGORIES as placeholderSubCategories, VARIANTS as placeholderVariants, MOUNTING_TYPES as placeholderMountingTypes } from '@/lib/placeholder-data';
import { useSearchParams } from 'next/navigation';
import { useAttributeData } from '@/hooks/use-attribute-data';

type ProductsPageClientProps = {
  products: Product[];
};

export default function ProductsPageClient({
  products,
}: ProductsPageClientProps) {
  const searchParams = useSearchParams();
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({
    productName: '',
    category: '',
    subcategory: '',
    variant: '',
    mountingType: '',
    cct: '',
    beamAngle: '',
    wattage: '',
    drivingCurrent: '',
    status: '',
  });

  const allCategories = useAttributeData('Categories', placeholderCategories);
  const allSubcategories = useAttributeData('Sub-Categories', placeholderSubCategories);
  const allVariants = useAttributeData('Variants', placeholderVariants);
  const allMountingTypes = useAttributeData('Mounting Types', placeholderMountingTypes);

  useEffect(() => {
    const filterParam = searchParams.get('filter');
    if (filterParam === 'pending-approval' || filterParam === 'pending') {
      handleFilterChange('status')('pending');
    }
    if (filterParam === 'this-month') {
        const now = new Date();
        const productsThisMonth = products.filter(p => {
            if (!p.createdAt) return false;
            const productDate = new Date(p.createdAt);
            return productDate.getMonth() === now.getMonth() && productDate.getFullYear() === now.getFullYear();
        }).map(p => p.id);

        handleFilterChange('productName')('###THIS_MONTH###');
    }
  }, [searchParams, products]);

  const handleFilterChange = (filterType: keyof typeof filters) => (value: string) => {
    const newFilters = { ...filters, [filterType]: value === '_all_' ? '' : value };

    // Reset subsequent filters when a parent filter changes
    const filterHierarchy: (keyof typeof filters)[] = [
        'category',
        'productName',
        'subcategory',
        'mountingType',
        'variant',
        'cct',
        'beamAngle',
        'wattage',
        'drivingCurrent',
    ];

    const changedIndex = filterHierarchy.indexOf(filterType);

    if (changedIndex !== -1) {
        for (let i = changedIndex + 1; i < filterHierarchy.length; i++) {
            newFilters[filterHierarchy[i]] = '';
        }
    }

    setFilters(newFilters);
  };
  
  const resetFilters = () => {
    setSearchTerm('');
    setFilters({
      productName: '',
      category: '',
      subcategory: '',
      variant: '',
      mountingType: '',
      cct: '',
      beamAngle: '',
      wattage: '',
      drivingCurrent: '',
      status: '',
    });
  };

  const activeFilter = Object.values(filters).some(v => v !== '') || searchTerm !== '';

  // Sequentially filtered lists
  const searchedProducts = useMemo(() => {
    if (filters.productName === '###THIS_MONTH###') {
        const now = new Date();
        return products.filter(p => {
            if (!p.createdAt) return false;
            const productDate = new Date(p.createdAt);
            return productDate.getMonth() === now.getMonth() && productDate.getFullYear() === now.getFullYear();
        });
    }
    return products.filter(p => searchTerm ? p.fixtureName.toLowerCase().includes(searchTerm.toLowerCase()) : true);
  }, [products, searchTerm, filters.productName]);

  const statusFilteredProducts = useMemo(() => {
      return searchedProducts.filter(p => filters.status ? p.status?.toLowerCase().includes(filters.status.toLowerCase()) : true);
  }, [searchedProducts, filters.status]);
  
  const categoryFilteredProducts = useMemo(() => {
      return statusFilteredProducts.filter(p => filters.category ? p.category === filters.category : true);
  }, [statusFilteredProducts, filters.category]);

  const productNameFilteredProducts = useMemo(() => {
    return categoryFilteredProducts.filter(p => filters.productName ? p.fixtureName === filters.productName : true);
  }, [categoryFilteredProducts, filters.productName]);

  const subcategoryFilteredProducts = useMemo(() => {
      return productNameFilteredProducts.filter(p => filters.subcategory ? p.subcategory === filters.subcategory : true);
  }, [productNameFilteredProducts, filters.subcategory]);
  
  const mountingTypeFilteredProducts = useMemo(() => {
    return subcategoryFilteredProducts.filter(p => filters.mountingType ? p.mountingType === filters.mountingType : true);
  }, [subcategoryFilteredProducts, filters.mountingType]);

  const variantFilteredProducts = useMemo(() => {
    return mountingTypeFilteredProducts.filter(p => filters.variant ? p.variant === filters.variant : true);
  }, [mountingTypeFilteredProducts, filters.variant]);

  const cctFilteredProducts = useMemo(() => {
    return variantFilteredProducts.filter(p => filters.cct ? p.cct === filters.cct : true);
  }, [variantFilteredProducts, filters.cct]);

  const beamAngleFilteredProducts = useMemo(() => {
    return cctFilteredProducts.filter(p => filters.beamAngle ? String(p.beamAngle) === filters.beamAngle : true);
  }, [cctFilteredProducts, filters.beamAngle]);

  const wattageFilteredProducts = useMemo(() => {
    return beamAngleFilteredProducts.filter(p => filters.wattage ? String(p.wattage) === filters.wattage : true);
  }, [beamAngleFilteredProducts, filters.wattage]);

  const finalFilteredProducts = useMemo(() => {
    return wattageFilteredProducts.filter(p => filters.drivingCurrent ? p.drivingCurrent === filters.drivingCurrent : true);
  }, [wattageFilteredProducts, filters.drivingCurrent]);


  // Dynamic options generation
  const getOptionsFromProducts = (products: Product[], key: keyof Product, sort: 'string' | 'number' = 'string') => {
    const options = [...new Set(products.map(p => p[key]).filter(Boolean))];
    if (sort === 'number') {
        return options.sort((a,b) => Number(a) - Number(b));
    }
    return options.sort((a,b) => String(a).localeCompare(String(b)));
  };

  const availableStatuses = useMemo(() => getOptionsFromProducts(products, 'status'), [products]);
  const availableCategories = useMemo(() => getOptionsFromProducts(statusFilteredProducts, 'category'), [statusFilteredProducts]);
  const availableProductNames = useMemo(() => getOptionsFromProducts(categoryFilteredProducts, 'fixtureName'), [categoryFilteredProducts]);
  const availableSubcategories = useMemo(() => getOptionsFromProducts(productNameFilteredProducts, 'subcategory'), [productNameFilteredProducts]);
  const availableMountingTypes = useMemo(() => getOptionsFromProducts(subcategoryFilteredProducts, 'mountingType'), [subcategoryFilteredProducts]);
  const availableVariants = useMemo(() => getOptionsFromProducts(mountingTypeFilteredProducts, 'variant'), [mountingTypeFilteredProducts]);
  const availableCCTs = useMemo(() => getOptionsFromProducts(variantFilteredProducts, 'cct'), [variantFilteredProducts]);
  const availableBeamAngles = useMemo(() => getOptionsFromProducts(cctFilteredProducts, 'beamAngle', 'number'), [cctFilteredProducts]);
  const availableWattages = useMemo(() => getOptionsFromProducts(beamAngleFilteredProducts, 'wattage', 'number'), [beamAngleFilteredProducts]);
  const availableDrivingCurrents = useMemo(() => getOptionsFromProducts(wattageFilteredProducts, 'drivingCurrent', 'number'), [wattageFilteredProducts]);
  

  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex flex-col gap-4">
          <div className="flex w-full items-center gap-2">
            <Input
              placeholder="Search products..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
            <Select onValueChange={handleFilterChange('status')} value={filters.status}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="_all_">All Statuses</SelectItem>
                {availableStatuses.map(s => <SelectItem key={String(s)} value={String(s).toLowerCase()}>{String(s)}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Select onValueChange={handleFilterChange('category')} value={filters.category}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                 <SelectItem value="_all_">All Categories</SelectItem>
                {availableCategories.map(c => <SelectItem key={String(c)} value={String(c)}>{String(c)}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select onValueChange={handleFilterChange('productName')} value={filters.productName}>
              <SelectTrigger className="w-[240px]">
                <SelectValue placeholder="Filter by product name..." />
              </SelectTrigger>
              <SelectContent>
                 <SelectItem value="_all_">All Products</SelectItem>
                {availableProductNames.map(name => <SelectItem key={String(name)} value={String(name)}>{String(name)}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select onValueChange={handleFilterChange('subcategory')} value={filters.subcategory}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Subcategory" />
              </SelectTrigger>
              <SelectContent>
                 <SelectItem value="_all_">All Subcategories</SelectItem>
                {availableSubcategories.map(s => <SelectItem key={String(s)} value={String(s)}>{String(s)}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select onValueChange={handleFilterChange('mountingType')} value={filters.mountingType}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Mounting" />
              </SelectTrigger>
              <SelectContent>
                 <SelectItem value="_all_">All Mountings</SelectItem>
                {availableMountingTypes.map(m => <SelectItem key={String(m)} value={String(m)}>{String(m)}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select onValueChange={handleFilterChange('variant')} value={filters.variant}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Variant" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="_all_">All Variants</SelectItem>
                {availableVariants.map(v => <SelectItem key={String(v)} value={String(v)}>{String(v)}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select onValueChange={handleFilterChange('cct')} value={filters.cct}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="CCT" />
              </SelectTrigger>
              <SelectContent>
                 <SelectItem value="_all_">All CCTs</SelectItem>
                {availableCCTs.map(c => <SelectItem key={String(c)} value={String(c)}>{String(c)}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select onValueChange={handleFilterChange('beamAngle')} value={filters.beamAngle}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Beam Angle" />
              </SelectTrigger>
              <SelectContent>
                 <SelectItem value="_all_">All Beam Angles</SelectItem>
                {availableBeamAngles.map(angle => <SelectItem key={String(angle)} value={String(angle)}>{angle}°</SelectItem>)}
              </SelectContent>
            </Select>
            <Select onValueChange={handleFilterChange('wattage')} value={filters.wattage}>
                <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Wattage" />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="_all_">All Wattages</SelectItem>
                    {availableWattages.map(wattage => <SelectItem key={String(wattage)} value={String(wattage)}>{wattage}W</SelectItem>)}
                </SelectContent>
            </Select>
            <Select onValueChange={handleFilterChange('drivingCurrent')} value={filters.drivingCurrent}>
                <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Driving Current" />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="_all_">All Currents</SelectItem>
                    {availableDrivingCurrents.map(current => <SelectItem key={String(current)} value={String(current)}>{current}mA</SelectItem>)}
                </SelectContent>
            </Select>
            {activeFilter && (
              <Button variant="ghost" onClick={resetFilters}>
                <X className="mr-2 h-4 w-4" />
                Reset
              </Button>
            )}
          </div>
          <ProductsTable products={finalFilteredProducts} />
        </div>
      </CardContent>
    </Card>
  );
}
