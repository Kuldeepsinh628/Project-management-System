
'use client';

import { use, useState, useEffect, useMemo } from 'react';
import PageHeader from '@/components/shared/PageHeader';
import ProductForm from '@/components/products/ProductForm';
import { useProducts } from '@/context/ProductContext';
import { notFound } from 'next/navigation';
import { Loader2 } from 'lucide-react';
import { type Product } from '@/lib/definitions';

type PageProps = {
  params: Promise<{ id: string }>;
};

export default function EditProductPage({ params }: PageProps) {
  const { id } = use(params);
  const { products } = useProducts();
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const product = useMemo(() => {
    if (!isClient) return undefined;
    return products.find(p => p.id === id);
  }, [isClient, products, id]);

  if (!isClient || product === undefined) {
    return (
      <div className="flex h-96 w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (isClient && !product) {
    notFound();
  }
  
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Edit Product"
        description={`Editing details for ${product.fixtureName}`}
      />
      <ProductForm product={product} />
    </div>
  );
}
