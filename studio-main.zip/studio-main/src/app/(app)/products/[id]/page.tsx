
'use client';

import { use, useState, useEffect } from 'react';
import { useProducts } from "@/context/ProductContext";
import { notFound } from "next/navigation";
import Image from "next/image";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import PageHeader from "@/components/shared/PageHeader";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { Edit, FileText, Download, Video, Loader2, ExternalLink, Ruler, BarChart3, Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { getDirectImageUrl, isGoogleDriveFolder } from '@/lib/utils';
import { type Product } from '@/lib/definitions';
import { useUser } from '@/firebase';
import { generateProductPdf } from '@/lib/pdf';
import { cn } from '@/lib/utils';

type PageProps = {
  params: Promise<{ id: string }>;
};

function DetailItem({ label, value, isBadge=false }: { label: string; value: string | number | boolean | undefined | null, isBadge?: boolean }) {
  if (value === undefined || value === null || value === '' || (typeof value === 'boolean' && !value)) return null;
  
  let displayValue: React.ReactNode;

  if (typeof value === 'boolean') {
    displayValue = <Badge variant={value ? "secondary" : "outline"}>{value ? 'Yes' : 'No'}</Badge>;
  } else if (isBadge) {
    displayValue = <Badge variant="secondary">{String(value)}</Badge>;
  } else {
    displayValue = <p className="text-base font-semibold">{String(value)}</p>;
  }

  return (
    <div className="flex flex-col gap-1">
      <p className="text-sm font-medium text-muted-foreground">{label}</p>
      {displayValue}
    </div>
  );
}

const FileButton = ({ href, icon: Icon, label }: { href?: string | null; icon: React.ElementType; label: string }) => {
  const isValidHref = href && href.trim() !== '';

  if (isValidHref) {
    return (
      <Button variant="outline" className="w-full justify-start" asChild>
        <a href={href} target="_blank" rel="noopener noreferrer">
          <Icon className="mr-2 h-4 w-4" />
          {label}
        </a>
      </Button>
    );
  }

  // Render a disabled-looking div if no valid href
  return (
    <div
      className={cn(
        "inline-flex items-center justify-start gap-2 whitespace-nowrap rounded-md text-sm font-medium h-10 px-4 py-2 w-full",
        "border border-input bg-background text-muted-foreground opacity-50 cursor-not-allowed"
      )}
    >
      <Icon className="mr-2 h-4 w-4" />
      {label} (N/A)
    </div>
  );
};


export default function ProductDetailPage({ params }: PageProps) {
  const { id } = use(params);
  const { toast } = useToast();
  const { products } = useProducts();
  const { user: appUser } = useUser();
  const [isClient, setIsClient] = useState(false);
  const [product, setProduct] = useState<Product | undefined>(undefined);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [mainImageUrl, setMainImageUrl] = useState<string>('');


  const canEdit = appUser?.role === 'Admin' || appUser?.role === 'Editor';

  useEffect(() => {
    setIsClient(true);
  }, []);

  useEffect(() => {
    if(isClient) {
        const foundProduct = products.find(p => p.id === id);
        setProduct(foundProduct);
        if (foundProduct) {
          setMainImageUrl(getDirectImageUrl(foundProduct.imageUrl));
        }
    }
  }, [isClient, products, id]);


  if (!isClient || product === undefined) {
    return (
      <div className="flex h-96 w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }
  
  if (isClient && !product) {
    notFound();
  }

  const handleGenerateDatasheet = async () => {
    if (!product) return;
    setIsGeneratingPdf(true);
    toast({
      title: 'Generating PDF...',
      description: `Please wait while we create the datasheet for "${product.fixtureName}".`,
    });
    try {
      await generateProductPdf(product);
      toast({
        title: 'PDF Generated',
        description: `The datasheet for "${product.fixtureName}" has been downloaded.`,
      });
    } catch (error) {
      console.error('PDF generation failed:', error);
      toast({
        variant: 'destructive',
        title: 'PDF Generation Failed',
        description: 'Could not generate the PDF. Please try again.',
      });
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const isFolder = isGoogleDriveFolder(product.imageUrl);

  const images = [
    product.imageUrl,
    product.dimensionUrl,
    product.photometricChartUrl
  ].filter(Boolean) as string[];

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title={product.fixtureName}
        description={product.nmw ? `NMW: ${product.nmw}` : `Variant: ${product.variant}`}
      >
        {canEdit && (
          <Button variant="outline" asChild>
            <Link href={`/products/${product.id}/edit`}>
              <Edit className="mr-2 h-4 w-4" />
              Edit Product
            </Link>
          </Button>
        )}
        <Button onClick={handleGenerateDatasheet} disabled={isGeneratingPdf}>
          {isGeneratingPdf ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <FileText className="mr-2 h-4 w-4" />}
          Generate Datasheet
        </Button>
        <Button variant="secondary">
          <Upload className="mr-2 h-4 w-4" />
          Upload to website
        </Button>
      </PageHeader>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Product Details</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Description</h3>
                  <p className="text-muted-foreground">{product.description}</p>
                </div>
                 <div>
                  <h3 className="text-lg font-semibold mb-2">Status</h3>
                  <DetailItem label="" value={product.status} isBadge={true} />
                </div>
                <Separator />
                <div className="grid grid-cols-2 gap-4 md:grid-cols-3">
                  <DetailItem label="Category" value={product.category} />
                  <DetailItem label="Subcategory" value={product.subcategory} />
                  <DetailItem label="Variant" value={product.variant} />
                  <DetailItem label="Mounting" value={product.mountingType} />
                  <DetailItem label="Colors" value={product.colors} />
                   <DetailItem label="Weight" value={product.weight ? `${product.weight} kg` : null} />
                </div>
                <Separator />
                 <h3 className="text-lg font-semibold">Technical Specifications</h3>
                <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
                  <DetailItem label="CCT" value={product.cct} />
                  <DetailItem label="CRI" value={product.cri} />
                  <DetailItem label="Wattage" value={product.wattage ? `${product.wattage}W` : undefined} />
                  <DetailItem label="Lumen Output" value={product.lumen ? `${product.lumen} lm` : undefined} />
                  <DetailItem label="Beam Angle" value={product.beamAngle ? `${product.beamAngle}°` : undefined} />
                  <DetailItem label="IP Rating" value={product.ipRating} />
                  <DetailItem label="IK Rating" value={product.ikRating} />
                  <DetailItem label="Efficacy" value={product.efficacy} />
                  <DetailItem label="Efficiency" value={product.efficiency} />
                  <DetailItem label="Driving Current" value={product.drivingCurrent} />
                  <DetailItem label="Lifetime" value={product.lifetime} />
                  <DetailItem label="Driver Type" value={product.driverType} />
                  <DetailItem label="THD" value={product.thd} />
                  <DetailItem label="UGR" value={product.ugr} />
                  <DetailItem label="Actual BUG" value={product.bcr} />
                  <DetailItem label="Binning" value={product.binning} />
                  <DetailItem label="Integrated Remote" value={product.integratedRemote} />
                  <DetailItem label="Tunable" value={product.tunable} isBadge={true} />
                  <DetailItem label="Dimmable" value={product.dimmable} isBadge={true} />
                  <DetailItem label="Tested Date" value={product.testedDate} />
                  <DetailItem label="Certificate Available" value={product.gunioReport} />
                </div>
                 <Separator />
                 <div>
                  <h3 className="text-lg font-semibold mb-2">Pricing</h3>
                   <div className="grid grid-cols-2 gap-4 md:grid-cols-5">
                      <DetailItem label="INR" value={product.priceINR ? `₹${product.priceINR.toLocaleString('en-IN')}` : null} />
                      <DetailItem label="USD" value={product.priceUSD ? `$${product.priceUSD.toLocaleString('en-US')}` : null} />
                      <DetailItem label="AED" value={product.priceAED ? `د.إ${product.priceAED.toLocaleString('ar-AE')}` : null} />
                      <DetailItem label="AUD" value={product.priceAUD ? `A$${product.priceAUD.toLocaleString('en-au')}` : null} />
                      <DetailItem label="GBP" value={product.priceGBP ? `£${product.priceGBP.toLocaleString('en-gb')}` : null} />
                   </div>
                </div>
                 <Separator />
                 <div>
                  <h3 className="text-lg font-semibold mb-2">Remarks</h3>
                  <p className="text-muted-foreground">{product.remarks}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardContent className="p-0">
               {isFolder ? (
                <a 
                  href={product.imageUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex aspect-[3/2] w-full items-center justify-center rounded-t-lg bg-secondary text-secondary-foreground"
                >
                  <div className="text-center">
                    <ExternalLink className="mx-auto h-8 w-8" />
                    <p className="mt-2 font-semibold">View Image Folder</p>
                  </div>
                </a>
              ) : (
                <Image
                  src={mainImageUrl}
                  alt={product.fixtureName}
                  width={600}
                  height={400}
                  className="rounded-t-lg object-cover w-full aspect-[3/2]"
                  data-ai-hint={product.imageHint}
                  onError={(e) => { e.currentTarget.src = 'https://picsum.photos/seed/placeholder-error/600/400'; }}
                  key={mainImageUrl}
                />
              )}
            </CardContent>
             <CardFooter className="p-4 flex-wrap gap-2">
              {images.map((img, index) => {
                 if (isGoogleDriveFolder(img)) {
                   return null;
                 }
                 return (
                    <Image
                      key={index}
                      src={getDirectImageUrl(img)}
                      alt={`${product.fixtureName} - image ${index+1}`}
                      width={60}
                      height={40}
                      className="rounded-md object-cover aspect-[3/2] border-2 border-transparent hover:border-primary cursor-pointer"
                      onError={(e) => { e.currentTarget.src = 'https://picsum.photos/seed/placeholder-error-thumb/60/40'; }}
                      onClick={() => setMainImageUrl(getDirectImageUrl(img))}
                    />
                 );
              })}
            </CardFooter>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Files & Documents</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <FileButton href={product.datasheetUrl} icon={Download} label="Datasheet" />
              <FileButton href={product.iesFileUrl} icon={Download} label="IES File" />
              <FileButton href={product.revitFileUrl} icon={Download} label="Revit Model" />
              <FileButton href={product.dimensionUrl} icon={Ruler} label="Dimensions" />
              <FileButton href={product.photometricChartUrl} icon={BarChart3} label="Photometric Chart" />
              <FileButton href={product.installationGuide} icon={Video} label="Installation Guide" />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

    