import PageHeader from '@/components/shared/PageHeader';
import ProductForm from '@/components/products/ProductForm';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Add Product | Plus Light Tech',
};

export default function AddProductPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Add New Product"
        description="Fill in the details to add a new product to the catalog."
      />
      <ProductForm />
    </div>
  );
}
