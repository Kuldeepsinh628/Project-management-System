
'use client';

import PageHeader from "@/components/shared/PageHeader";
import { Button } from "@/components/ui/button";
import { PlusCircle, Upload, Loader2 } from "lucide-react";
import Link from "next/link";
import ProductsPageClient from "./ProductsPageClient";
import { useProducts } from "@/context/ProductContext";
import { useUser } from "@/firebase";
import { useState, useEffect } from "react";

export default function ProductsPage() {
  const { products } = useProducts();
  const { user: appUser } = useUser();
  const [isClient, setIsClient] = useState(false);
  
  const canEdit = appUser?.role === 'Admin' || appUser?.role === 'Editor';

  useEffect(() => {
    setIsClient(true);
  }, []);

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Products"
        description="Manage your entire product catalog with ease."
      >
        {canEdit && (
          <>
            <Button variant="outline" asChild>
              <Link href="/import">
                <Upload className="mr-2 h-4 w-4" />
                Import
              </Link>
            </Button>
            <Button asChild>
              <Link href="/products/add">
                <PlusCircle className="mr-2 h-4 w-4" />
                Add Product
              </Link>
            </Button>
          </>
        )}
      </PageHeader>
      {isClient ? (
        <ProductsPageClient products={products} />
      ) : (
        <div className="flex items-center justify-center p-12">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      )}
    </div>
  );
}
