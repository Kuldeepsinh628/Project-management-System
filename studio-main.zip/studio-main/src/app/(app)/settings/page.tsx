
'use client';

import PageHeader from "@/components/shared/PageHeader";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import AccountForm from "@/components/settings/AccountForm";
import PasswordForm from "@/components/settings/PasswordForm";
import AttributesTable from "@/components/settings/AttributesTable";
import { CATEGORIES, MOUNTING_TYPES, VARIANTS, SUBCATEGORIES } from "@/lib/placeholder-data";
import { useUser } from "@/firebase";

export default function SettingsPage() {
  const { user: appUser } = useUser();

  const isAdmin = appUser?.role === 'Admin';
  const canEditAttributes = isAdmin || appUser?.role === 'Editor';

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Settings"
        description="Manage your account and application settings."
      />
      <Tabs defaultValue="account" className="w-full">
        <TabsList className="grid w-full grid-cols-2 md:w-auto md:grid-cols-3">
          <TabsTrigger value="account">Account</TabsTrigger>
          <TabsTrigger value="password">Password</TabsTrigger>
          {canEditAttributes && <TabsTrigger value="attributes">Attributes</TabsTrigger>}
        </TabsList>
        <TabsContent value="account">
          <AccountForm user={appUser} />
        </TabsContent>
        <TabsContent value="password">
          <PasswordForm />
        </TabsContent>
        {canEditAttributes && (
          <TabsContent value="attributes">
            <div className="grid gap-6 md:grid-cols-2">
              <AttributesTable title="Categories" data={CATEGORIES} />
              <AttributesTable title="Sub-Categories" data={SUBCATEGORIES} />
              <AttributesTable title="Variants" data={VARIANTS} />
              <AttributesTable title="Mounting Types" data={MOUNTING_TYPES} />
            </div>
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
}

    