
'use client';

import StatCard from '@/components/dashboard/StatCard';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useAttributeData } from '@/hooks/use-attribute-data';
import { CATEGORIES as placeholderCategories } from '@/lib/placeholder-data';
import { BarChart3, Grip, Package, Clock } from 'lucide-react';
import ProductsTable from '@/components/products/ProductsTable';
import PageHeader from '@/components/shared/PageHeader';
import { useProducts } from '@/context/ProductContext';
import { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';
import Link from 'next/link';

export default function Dashboard() {
  const { products } = useProducts();
  const categories = useAttributeData('Categories', placeholderCategories);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
    // Set document title on client
    document.title = 'Dashboard | Lumina Product Hub';
  }, []);

  if (!isClient) {
    return (
      <div className="flex h-96 w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const totalProducts = products.length;
  const totalCategories = categories.length;
  const recentProducts = products.slice(0, 5);

  const productsThisMonth = products.filter(p => {
    if (!p.createdAt) return false;
    const productDate = new Date(p.createdAt);
    const now = new Date();
    return productDate.getMonth() === now.getMonth() && productDate.getFullYear() === now.getFullYear();
  }).length;
  
  const pendingApproval = products.filter(p => p.status?.toLowerCase().includes('pending')).length;

  return (
    <div className="flex flex-col gap-6">
      <PageHeader title="Dashboard" description="An overview of your product catalog." />
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          label="Total Products"
          value={totalProducts}
          icon={Package}
        />
        <StatCard
          label="Total Categories"
          value={totalCategories}
          icon={Grip}
        />
        <Link href="/products?filter=this-month">
          <StatCard label="Products This Month" value={productsThisMonth} icon={BarChart3} />
        </Link>
        <Link href="/products?filter=pending">
          <StatCard label="Pending" value={pendingApproval} icon={Clock} />
        </Link>
      </div>
      <div className="grid grid-cols-1 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Recently Added Products</CardTitle>
          </CardHeader>
          <CardContent>
            <ProductsTable products={recentProducts} variant="compact" />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
