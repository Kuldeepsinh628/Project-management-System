
'use client';

import PageHeader from "@/components/shared/PageHeader";
import UsersTable from "@/components/settings/UsersTable";
import { type User } from "@/lib/definitions";
import { useState, useEffect } from "react";
import { USERS as placeholderUsers } from "@/lib/placeholder-data";

const getInitialUsers = (): User[] => {
  if (typeof window !== 'undefined') {
    try {
      const storedUsers = window.localStorage.getItem('users');
      return storedUsers ? JSON.parse(storedUsers) : placeholderUsers;
    } catch (error) {
      console.error("Failed to parse users from localStorage", error);
      return placeholderUsers;
    }
  }
  return placeholderUsers;
}


export default function UsersPage() {
  const [users, setUsers] = useState<User[]>([]);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    const initialUsers = getInitialUsers();
    setUsers(initialUsers);

    if (typeof window !== 'undefined' && !window.localStorage.getItem('users')) {
      window.localStorage.setItem('users', JSON.stringify(placeholderUsers));
    }
    
    setIsClient(true);
  }, []);
  
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Users"
        description="Manage all user accounts and their roles."
      />
      {isClient ? (
         <UsersTable initialUsers={users || []} />
      ) : (
        <div className="rounded-lg border p-12 text-center text-muted-foreground">Loading users...</div>
      )}
    </div>
  );
}
