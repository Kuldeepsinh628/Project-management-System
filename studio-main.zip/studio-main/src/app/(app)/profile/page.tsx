
'use client';

import PageHeader from "@/components/shared/PageHeader";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import AccountForm from "@/components/settings/AccountForm";
import PasswordForm from "@/components/settings/PasswordForm";
import { useUser } from "@/firebase";

export default function ProfilePage() {
  const { user: appUser } = useUser();
  
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="My Profile"
        description="View and manage your account details."
      />
      <Tabs defaultValue="account" className="w-full max-w-2xl">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="account">Account</TabsTrigger>
          <TabsTrigger value="password">Password</TabsTrigger>
        </TabsList>
        <TabsContent value="account">
          <AccountForm user={appUser} />
        </TabsContent>
        <TabsContent value="password">
          <PasswordForm />
        </TabsContent>
      </Tabs>
    </div>
  );
}
