'use client';

import PageHeader from "@/components/shared/PageHeader";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

export default function WordpressPage() {
  const { toast } = useToast();

  const handleSave = () => {
    toast({
      title: 'Credentials Saved',
      description: 'Your WordPress API credentials have been saved.',
    });
  };

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="WordPress Integration"
        description="Connect your WordPress site to sync products automatically."
      />
      <Card className="max-w-xl">
        <CardHeader>
          <CardTitle>API Credentials</CardTitle>
          <CardDescription>
            Enter the API credentials for your WordPress site. This feature is currently in development.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-2">
            <Label htmlFor="wp-url">WordPress Site URL</Label>
            <Input id="wp-url" placeholder="https://example.com" />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="wp-key">Consumer Key</Label>
            <Input id="wp-key" placeholder="ck_xxxxxxxxxxxxxxxxxxxxxxxx" />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="wp-secret">Consumer Secret</Label>
            <Input id="wp-secret" type="password" placeholder="cs_xxxxxxxxxxxxxxxxxxxxxxxx" />
          </div>
        </CardContent>
        <CardFooter className="border-t px-6 py-4">
          <Button onClick={handleSave}>Save Credentials</Button>
        </CardFooter>
      </Card>
    </div>
  );
}
