
'use client';

import {
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState, FormEvent, useEffect } from 'react';
import { Eye, EyeOff, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useUser } from '@/firebase';
import { USERS as placeholderUsers } from '@/lib/placeholder-data';
import type { User as AppUser } from '@/lib/definitions';

export default function LoginPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const { user, isUserLoading } = useUser();

  useEffect(() => {
    if (user && !isUserLoading) {
      router.push('/dashboard');
    }
  }, [user, isUserLoading, router]);

  const handleLogin = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    const formData = new FormData(e.target as HTMLFormElement);
    const email = formData.get('email') as string;
    const password = formData.get('password') as string;

    // Mock login logic
    setTimeout(() => {
      const storedUsersString = localStorage.getItem('users');
      const storedUsers: (AppUser & { password?: string})[] = storedUsersString ? JSON.parse(storedUsersString) : [];
      
      const userMap = new Map<string, AppUser & { password?: string }>();

      const placeholderUsersWithPassword = placeholderUsers.map(u => ({...u, password: 'password'}));

      // Add placeholder users first
      for (const pUser of placeholderUsersWithPassword) {
        userMap.set(pUser.email.toLowerCase(), pUser);
      }

      // Add/overwrite with users from local storage (newly signed up users)
      for (const sUser of storedUsers) {
        userMap.set(sUser.email.toLowerCase(), sUser);
      }
      
      const allUsers = Array.from(userMap.values());
      const foundUser = allUsers.find(u => u.email.toLowerCase() === email.toLowerCase());

      // Use the stored password if available, otherwise default to 'password' for mock users
      const expectedPassword = foundUser?.password || 'password';

      if (foundUser && password === expectedPassword) { 
        sessionStorage.setItem('loggedInUser', JSON.stringify(foundUser));

        toast({
          title: 'Login Successful',
          description: `Welcome back, ${foundUser.name}!`,
        });
        router.push('/dashboard');
      } else {
        toast({
          variant: "destructive",
          title: 'Login Failed',
          description: "Invalid email or password. For mock users, the password is 'password'.",
        });
      }
      setLoading(false);
    }, 500);
  };

  if (isUserLoading || user) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <form onSubmit={handleLogin}>
      <CardHeader>
        <CardTitle className="text-2xl font-headline">Login</CardTitle>
        <CardDescription>
          Enter your email below to login to your account.
        </CardDescription>
      </CardHeader>
      <CardContent className="grid gap-4">
        <div className="grid gap-2">
          <Label htmlFor="email">Email</Label>
          <Input id="email" name="email" type="email" placeholder="m@example.com" required defaultValue="admin@lumina.com" />
        </div>
        <div className="grid gap-2">
          <div className="flex items-center">
            <Label htmlFor="password">Password</Label>
            <Link href="/forgot-password" className="ml-auto inline-block text-sm underline">
              Forgot your password?
            </Link>
          </div>
          <div className="relative">
            <Input id="password" name="password" type={showPassword ? 'text' : 'password'} required defaultValue="password" />
             <Button
              type="button"
              variant="ghost"
              size="icon"
              className="absolute right-1 top-1/2 h-7 w-7 -translate-y-1/2 text-muted-foreground"
              onClick={() => setShowPassword(prev => !prev)}
              disabled={loading}
            >
              {showPassword ? <EyeOff /> : <Eye />}
              <span className="sr-only">{showPassword ? 'Hide password' : 'Show password'}</span>
            </Button>
          </div>
        </div>
        <Button type="submit" className="w-full" disabled={loading}>
          {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Login
        </Button>
      </CardContent>
      <CardFooter className="text-center text-sm">
        Don&apos;t have an account?{' '}
        <Link href="/signup" className="underline">
          Sign up
        </Link>
      </CardFooter>
    </form>
  );
}
