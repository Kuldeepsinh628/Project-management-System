
'use client';

import {
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import { useState, FormEvent } from 'react';
import { Eye, EyeOff, Loader2 } from 'lucide-react';
import type { User as AppUser } from '@/lib/definitions';

export default function SignupPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSignup = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const formData = new FormData(e.target as HTMLFormElement);
    const name = formData.get('full-name') as string;
    const email = formData.get('email') as string;
    const password = formData.get('password') as string;

    // Mock signup logic
    setTimeout(() => {
      try {
        const storedUsersString = localStorage.getItem('users');
        const storedUsers: (AppUser & { password?: string })[] = storedUsersString ? JSON.parse(storedUsersString) : [];

        if (storedUsers.find(u => u.email.toLowerCase() === email.toLowerCase())) {
          toast({
            variant: "destructive",
            title: 'Signup Failed',
            description: 'An account with this email already exists.',
          });
          setLoading(false);
          return;
        }

        const isFirstUser = storedUsers.length === 0;

        const newUser: AppUser & { password?: string } = {
          id: `usr-${Date.now()}`,
          name: name,
          email: email,
          password: password, // Save the password
          avatarUrl: `https://picsum.photos/seed/${Date.now()}/100/100`,
          role: isFirstUser ? 'Admin' : 'Viewer' // First user is admin, others are viewers
        };

        const updatedUsers = [...storedUsers, newUser];
        localStorage.setItem('users', JSON.stringify(updatedUsers));
        
        // Also log the user in by setting session storage
        sessionStorage.setItem('loggedInUser', JSON.stringify(newUser));

        toast({
          title: 'Account Created',
          description: 'Your account has been successfully created.',
        });
        router.push('/dashboard');

      } catch (error: any) {
        toast({
          variant: "destructive",
          title: 'Signup Failed',
          description: error.message || 'Could not create account.',
        });
      } finally {
        setLoading(false);
      }
    }, 500);
  };

  return (
    <form onSubmit={handleSignup}>
      <CardHeader>
        <CardTitle className="text-2xl font-headline">Sign Up</CardTitle>
        <CardDescription>
          Enter your information to create an account
        </CardDescription>
      </CardHeader>
      <CardContent className="grid gap-4">
        <div className="grid gap-2">
          <Label htmlFor="full-name">Full name</Label>
          <Input id="full-name" name="full-name" placeholder="John Doe" required />
        </div>
        <div className="grid gap-2">
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            name="email"
            type="email"
            placeholder="m@example.com"
            required
          />
        </div>
        <div className="grid gap-2">
          <Label htmlFor="password">Password</Label>
          <div className="relative">
            <Input id="password" name="password" type={showPassword ? 'text' : 'password'} required />
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="absolute right-1 top-1/2 h-7 w-7 -translate-y-1/2 text-muted-foreground"
              onClick={() => setShowPassword(prev => !prev)}
              disabled={loading}
            >
              {showPassword ? <EyeOff /> : <Eye />}
              <span className="sr-only">{showPassword ? 'Hide password' : 'Show password'}</span>
            </Button>
          </div>
        </div>
        <Button type="submit" className="w-full" disabled={loading}>
          {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Create an account
        </Button>
      </CardContent>
      <CardFooter className="text-center text-sm">
        Already have an account?{' '}
        <Link href="/login" className="underline">
          Sign in
        </Link>
      </CardFooter>
    </form>
  );
}
