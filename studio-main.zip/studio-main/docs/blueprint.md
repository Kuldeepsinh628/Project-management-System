# **App Name**: Lumina Product Hub

## Core Features:

- Secure User Authentication: Implement user signup, sign-in, and password reset functionalities using secure authentication methods.
- Role-Based Access Control: Restrict data and function access based on user roles (Viewer, Editor, Admin).
- Product Data Management: Enable editors and admins to create, edit, and manage lighting product data (name, specs, images, files).
- Filtering & Searching: Enable searching for products based on name and filtering of products based on category, subcategory, mounting type or CCT.
- Bulk CSV Import/Export: Import and export product data in bulk using CSV files, including template.
- Datasheet Generator: Generate professional-grade PDF datasheets manually or from existing product data.
- AI Marketing Assistant: A tool for generating marketing copy for products, with options for target audience and tone.

## Style Guidelines:

- Primary color: Midnight blue (#2C3E50) for a professional and trustworthy feel.
- Background color: Light gray (#F0F4F8) to provide a clean, uncluttered backdrop.
- Accent color: Sky blue (#3498DB) for highlighting key actions and elements.
- Headline font: 'Space Grotesk' (sans-serif) for a techy, scientific feel in headlines; body font: 'Inter' (sans-serif) for neutral, readable body text.
- Code font: 'Source Code Pro' (monospace) for code snippets.
- Use simple, professional icons representing different product attributes and actions.
- Maintain a clean, well-organized layout with clear information hierarchy for easy navigation.
- Subtle transitions and loading animations to provide visual feedback without being distracting.